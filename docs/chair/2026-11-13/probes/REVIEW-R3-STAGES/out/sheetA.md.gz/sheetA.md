# Reading sheet A01,A02,A03,A04,A05,A06,A07,A08,A10,A11,A12,A13,A14,A15,A16,A17,A18,A19,A19b,A20,A21,A22,A23,A24,A25,A26,A27,A28,A29,A30,A31,A32,A33,A34,A35,A36,A37,A38

## A01 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs population ≥ middling (new) · prints in 235 towns (town,city,metropolis)

### r2r-metropolis-14
    tier metropolis pop 271164 · crisis under_siege · prosperity Struggling · route crossroads · terrain plains
    powers 8: High Theocratic Council[religious 24]; Religious Authorities[religious 23]; Military/Guard[military 13]; War Council[military 12]; Arcane Orders[magic 6]; Noble Houses[noble 5]; Craft Guilds[economy 4]; The Holy Compact[religious 13] · govt 
    houses (98) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Dressed stone (local quarry depleted)","Wool","Iron ore (local mines exhausted)","Luxury materials","Precious metals","Grain","Medicinal herbs","Paper","Paper materials","Coal and fuel (local seams exhausted)"]
    history: The Pilgrimage(minor,360y,religious); The Siege(major,349y,disaster); The Economic Divide(minor,302y,economic); The Religious Conflict(minor,258y,religious); The Arcane Incident(minor,223y,magical); The Occupation(catastrophic,180y,exile_return); The Great Fire(catastrophic,169y,disaster); The Migration(major,140y,demographic); The Scandal(major,95y,political); The Purge(major,84y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] They've been quietly buying up property in a district that hasn't been announced as a development site. Yet.

### r2r-city-44
    tier city pop 2408 · crisis famine · prosperity Struggling · route river · terrain coastal
    powers 5: Religious Authorities[religious 31]; Military/Guard[military 24]; Ecclesiastical Council[religious 15]; The Order of the Watch[military 13]; The Holy Compact[religious 17] · govt 
    houses (39) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Barge and river transport company; Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Sawmill (commercial); Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Black market
    food: sources ["fish"] failed fish granary true · balance {"imp":2178} · exports ["Salted fish","Smoked seafood","Fish oil","Medicinal herbs","Wild honey","Sacred wood","Ritual components","Luxury manufactured goods","Fine metalwork and jewelry","Herbal remedies","Potions and elixirs","Rare spices and exotic dyes","Quality tools and weapons","Legal services (contracts, notarial)","Military contract services","Waterborne freight services (cargo, pilotage)"] imports ["Iron","Grain","Salt","Cut stone and masonry","Clay and raw materials","Luxury textiles and exotic goods","Coal and fuel (local seams exhausted)","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Fine pottery for libations"]
    history: The Heresy Trials(minor,120y,religious); The Religious Conflict(minor,112y,religious); The Great Construction(major,84y,economic); The Purge(major,83y,occupation_infiltration); The Siege(catastrophic,61y,disaster); The Succession Crisis(minor,31y,political); The Occupation(major,8y,exile_return)
    PAGE: [Summary/Plot Hooks] They've been quietly buying up property in a district that hasn't been announced as a development site. Yet.

### r2s-occupied-town-0
    tier town pop 1580 · crisis occupied · prosperity Poor · route road · terrain hills
    powers 4: Occupation Authority[military 41]; Town Council[government 28]; Resistance Network[military 17]; Merchant Guilds[economy 14] · govt 
    houses (33) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Adventurers' charter hall; Hireling hall; Town walls; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":870} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)","Legal services (contracts, notarial)"] imports ["Wool","Iron","Grain","Salt","Livestock and dairy (local pastures depleted)","Quality weapons and armour","Incense and votive candles","Lorica segmentata fittings","Fine wine and amphorae"]
    history: The Succession Crisis(minor,97y,political); The Migration(major,63y,demographic); The Purge(major,29y,occupation_infiltration); The Arcane Incident(minor,19y,magical)
    PAGE: [Summary/Plot Hooks] They've been quietly buying up property in a district that hasn't been announced as a development site. Yet.

### rr3-town-infiltrated-rand-5
    tier town pop 381 · crisis infiltrated · prosperity Comfortable · route river · terrain plains
    powers 3: Merchant Council[economy 43]; Merchant Guilds[economy 38]; Craft Guilds[economy 19] · govt 
    houses (19) key: Weekly market; Market square; Docks/port facilities; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town hall; Town watch; Town walls; Harbour master's office
    food: sources [] failed null granary true · balance {"imp":52} · exports ["Healing waters (bottled)","Pilgrim hospitality","Coal","Waterborne freight services (cargo, pilotage)"] imports ["Dressed stone (local quarry depleted)","Iron","Grain","Ritual wood and herbs (ancient grove damaged)","Replacement arms and basic equipment","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Felt and leather goods","Iron fittings and arrowheads"]
    history: The Scandal(major,113y,political); The Arcane Incident(major,65y,magical)
    PAGE: [Summary/Plot Hooks] They've been quietly buying up property in a district that hasn't been announced as a development site. Yet.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] They've been quietly buying up property in a district that hasn't been announced as a development site. Yet.

## A02 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs tier ≥ village (new) · prints in 257 towns (village,town,city,metropolis)

### r2s-under_siege-metropolis-1
    tier metropolis pop 70862 · crisis under_siege · prosperity Struggling · route port · terrain coastal
    powers 7: Grand Military Council[military 32]; Military/Guard[military 26]; Noble Houses[noble 8]; War Council[military 8]; Arcane Orders[magic 7]; The Garrison Bloc[military 14]; The Shield Compact[military 5] · govt 
    houses (95) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Docks/port facilities; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Black market bazaar; Elder Grove Council
    food: sources ["fish"] failed null granary true · balance {"imp":0} · exports ["Ship passage (naval route only)","Financial services (letters of credit)","Legal services (contracts, notarial)","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Maritime services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Shipbuilding timber (coastal stands cleared)","Precious metals","Iron (weapons)","Grain","Paper","Paper materials","Luxury materials","Salt","Salted fish (local fishing grounds exhausted)","Arcane reagents and energy (local ley node exhausted)"]
    history: The Tyranny(major,681y,political); The Occupation(major,611y,exile_return); The Wild Magic(minor,468y,magical); The Siege(catastrophic,438y,disaster); The Purge(major,355y,occupation_infiltration); The Succession Crisis(minor,320y,political); The Arcane Incident(minor,226y,magical); The Migration(minor,78y,demographic); The Economic Divide(minor,57y,economic)
    PAGE: [Summary/Plot Hooks] One of their staff has started asking questions about records from seven years ago. They've been reassigned twice already.

### r2s-famine-city-3
    tier city pop 11818 · crisis famine · prosperity Struggling · route crossroads · terrain plains
    powers 7: Religious Authorities[religious 21]; Noble Families[noble 16]; Military/Guard[military 16]; Noble Governorship[government 15]; Grain Holders[economy 11]; The Old Houses[noble 9]; The Holy Compact[religious 12] · govt 
    houses (69) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; Elder Grove Council; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Multiple adventurers' guilds
    food: sources [] failed null granary true · balance {"imp":11586} · exports ["Milled flour","Transit trade","Toll revenue","Coal","Raw wool","Livestock","Glassware","Books and manuscripts","Cavalry mounts","Draft horses","Processed textiles","Quality tools and weapons","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Medicinal herbs","Paper materials","Timber","Stone","Salt","Grain","Precious metals and bullion","Luxury textiles and exotic goods","Gemstones (local deposits exhausted)","Game and hides (local hunting grounds exhausted)"]
    history: The Interregnum(catastrophic,319y,political); The Crash(major,299y,economic); The Occupation(catastrophic,249y,exile_return); The Succession Crisis(major,239y,political); The Heresy Trials(minor,205y,religious); The Siege(major,164y,disaster); The Arcane Incident(minor,131y,magical); The Migration(major,117y,demographic); The Economic Divide(minor,84y,economic); The Great Fire(major,46y,disaster); The Purge(major,24y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] One of their staff has started asking questions about records from seven years ago. They've been reassigned twice already.

### r2s-occupied-town-0
    tier town pop 1580 · crisis occupied · prosperity Poor · route road · terrain hills
    powers 4: Occupation Authority[military 41]; Town Council[government 28]; Resistance Network[military 17]; Merchant Guilds[economy 14] · govt 
    houses (33) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Adventurers' charter hall; Hireling hall; Town walls; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":870} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)","Legal services (contracts, notarial)"] imports ["Wool","Iron","Grain","Salt","Livestock and dairy (local pastures depleted)","Quality weapons and armour","Incense and votive candles","Lorica segmentata fittings","Fine wine and amphorae"]
    history: The Succession Crisis(minor,97y,political); The Migration(major,63y,demographic); The Purge(major,29y,occupation_infiltration); The Arcane Incident(minor,19y,magical)
    PAGE: [Summary/Plot Hooks] One of their staff has started asking questions about records from seven years ago. They've been reassigned twice already.

### rr3-village-insurgency-rand-4
    tier village pop 112 · crisis insurgency · prosperity Poor · route crossroads · terrain riverside
    powers 2: Military/Guard[military 64]; Headman's Authority[government 36] · govt 
    houses (14) key: Mill; Parish church; Priest (resident); Palisade or earthworks; Citizen militia
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["Grain surplus","Milled flour","Transit trade","Toll revenue","Medicinal herbs","Wild honey","Baked goods","Preserved foods"] imports ["Salt","Cut stone and masonry","Replacement arms and basic equipment","Incense and votive candles","Cavalry horses and tack"]
    history: The Purge(major,43y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] One of their staff has started asking questions about records from seven years ago. They've been reassigned twice already.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] One of their staff has started asking questions about records from seven years ago. They've been reassigned twice already.

## A03 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs tier ≥ village (new) · prints in 270 towns (village,town,city,metropolis)

### r2s-under_siege-town-2
    tier town pop 2453 · crisis under_siege · prosperity Struggling · route isolated · terrain mountain
    powers 5: Military/Guard[military 32]; Feudal Appointee[noble 19]; Landed Gentry[noble 19]; Religious Authorities[religious 18]; War Council[military 12] · govt 
    houses (29) key: Weekly market; Market square; Town granary; Mills (2-5); Cobbler's guild; Craft guilds (5-15); Parish churches (2-5); Town hall; Town watch; Teleportation circle; Hireling hall; Fish market
    food: sources [] failed null granary true · balance {"imp":582} · exports ["Financial services (letters of credit)"] imports ["Grain","Salt","Iron (weapons)","Preserved provisions","Wool, dairy, and livestock (local alpine pasture depleted)","Incense, ritual oil, and vestment materials","Composite bow materials","Felt for yurt-shrines"]
    history: The Religious Conflict(minor,264y,religious); The Uprising(major,254y,political); The Migration(minor,207y,demographic); The Economic Divide(major,172y,economic); The Siege(catastrophic,145y,disaster); The Succession Crisis(major,109y,political); The Purge(major,39y,occupation_infiltration); The Arcane Incident(minor,9y,magical)
    PAGE: [Summary/Plot Hooks] Their most trusted advisor hasn't been seen in four days. The official story changes each time it's told.

### r2s-famine-town-0
    tier town pop 1696 · crisis famine · prosperity Struggling · route crossroads · terrain plains
    powers 3: Guild Council[economy 38]; Religious Authorities[religious 33]; Merchant Guilds[economy 29] · govt 
    houses (36) key: Fish market; Weekly market; Market square; Merchant guilds (3-8); Town granary; Mills (2-5); Bowyers & fletchers (guild); Craft guilds (5-15); Parish churches (2-5); Guild governance; Town hall; Town watch; Cobbler's guild; Courthouse
    food: sources [] failed null granary true · balance {"imp":1444} · exports ["Transit trade","Toll revenue","Iron ore","Quarried stone","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Quality tools and weapons","Advanced weapons and armor","Refined iron ingots","Pig iron","Legal services (contracts, notarial)"] imports ["Grain","Salt","Charcoal and fuel","Preserved provisions","Herbs and forage (local gathering areas exhausted)","Replacement arms and basic equipment","Incense and votive candles","Fine cloth and dye","Carved wood and amber"]
    history: The Arcane Incident(minor,208y,magical); The Shortage(major,177y,economic); The Iron Dispute(major,118y,economic); The Occupation(major,108y,exile_return); The Flood(major,75y,disaster); The Migration(minor,34y,political); The Religious Conflict(major,8y,religious)
    PAGE: [Summary/Plot Hooks] Their most trusted advisor hasn't been seen in four days. The official story changes each time it's told.

### r2s-occupied-village-3
    tier village pop 134 · crisis occupied · prosperity Struggling · route road · terrain hills
    powers 2: Occupation Authority[military 68]; Elder Council[government 32] · govt 
    houses (9) key: Mill; Parish church; Priest (resident)
    food: sources ["game"] failed null granary false · balance {"imp":22} · exports ["Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)","Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Herbal remedies (taxed by occupation)"] imports ["Salt","Iron arrowheads and spearheads"]
    history: The Religious Conflict(minor,103y,religious); The Plague Years(major,80y,disaster); The Economic Divide(major,55y,economic); The Migration(major,34y,political); The Purge(major,18y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] Their most trusted advisor hasn't been seen in four days. The official story changes each time it's told.

### rr3-village-insurgency-rand-0
    tier village pop 93 · crisis insurgency · prosperity Struggling · route river · terrain coastal
    powers 2: People's Council[government 53]; Elder Council[government 47] · govt 
    houses (12) key: Mill; Parish church; Priest (resident)
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Salted fish","Smoked seafood","Fish oil","Reeds and thatch","Coal","Waterfowl","Healing waters (bottled)","Pilgrim hospitality"] imports ["Route maps and intelligence","Incense and votive candles","Cordage, canvas, and vessel-maintenance supplies","Fine porcelain and lacquerware"]
    history: The Purge(major,135y,occupation_infiltration); The Occupation(major,97y,exile_return); The Succession Crisis(major,61y,political); The Arcane Incident(minor,52y,magical); The Economic Divide(major,28y,economic)
    PAGE: [Summary/Plot Hooks] Their most trusted advisor hasn't been seen in four days. The official story changes each time it's told.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] Their most trusted advisor hasn't been seen in four days. The official story changes each time it's told.

## A04 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs tier ≥ village (new) · prints in 257 towns (village,town,city,metropolis)

### r2r-metropolis-14
    tier metropolis pop 271164 · crisis under_siege · prosperity Struggling · route crossroads · terrain plains
    powers 8: High Theocratic Council[religious 24]; Religious Authorities[religious 23]; Military/Guard[military 13]; War Council[military 12]; Arcane Orders[magic 6]; Noble Houses[noble 5]; Craft Guilds[economy 4]; The Holy Compact[religious 13] · govt 
    houses (98) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Dressed stone (local quarry depleted)","Wool","Iron ore (local mines exhausted)","Luxury materials","Precious metals","Grain","Medicinal herbs","Paper","Paper materials","Coal and fuel (local seams exhausted)"]
    history: The Pilgrimage(minor,360y,religious); The Siege(major,349y,disaster); The Economic Divide(minor,302y,economic); The Religious Conflict(minor,258y,religious); The Arcane Incident(minor,223y,magical); The Occupation(catastrophic,180y,exile_return); The Great Fire(catastrophic,169y,disaster); The Migration(major,140y,demographic); The Scandal(major,95y,political); The Purge(major,84y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] Someone has been leaving anonymous notes in their office pointing to a colleague's corruption. The notes are accurate.

### r2s-famine-metropolis-2
    tier metropolis pop 29083 · crisis famine · prosperity Struggling · route river · terrain riverside
    powers 7: City-State Council[government 26]; Religious Authorities[religious 25]; Grain Holders[economy 13]; Arcane Orders[magic 12]; Thieves' Guild[criminal 11]; The Arcane Circle[magic 7]; The Shadow Compact[criminal 6] · govt 
    houses (81) key: District markets (5-10); Multiple market squares; State granary complex; Mills (2-5); Sawmill (commercial); Cobbler's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Airship docking (high magic); Merchant guilds (50-100+); Multiple adventurers' guilds
    food: sources [] failed null granary true · balance {"imp":28631} · exports ["Sacred wood","Ritual components","Raw wool","Livestock","Roof tiles","Coal","Wild honey","Candles and wax","Spellcasting (minor)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Bulk grain (local fields depleted)","Timber (local forests cleared)","Stone","Iron ore (local mines exhausted)","Paper","Paper materials","Salt","Luxury textiles and exotic goods","Bulk raw materials and agricultural goods","Salted fish (local river fishery exhausted)"]
    history: The Great Harvest Compact(major,167y,economic); The Succession Crisis(minor,123y,political); The Occupation(major,118y,exile_return); The Siege(major,25y,disaster)
    PAGE: [Summary/Plot Hooks] Someone has been leaving anonymous notes in their office pointing to a colleague's corruption. The notes are accurate.

### r2s-occupied-town-0
    tier town pop 1580 · crisis occupied · prosperity Poor · route road · terrain hills
    powers 4: Occupation Authority[military 41]; Town Council[government 28]; Resistance Network[military 17]; Merchant Guilds[economy 14] · govt 
    houses (33) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Adventurers' charter hall; Hireling hall; Town walls; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":870} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)","Legal services (contracts, notarial)"] imports ["Wool","Iron","Grain","Salt","Livestock and dairy (local pastures depleted)","Quality weapons and armour","Incense and votive candles","Lorica segmentata fittings","Fine wine and amphorae"]
    history: The Succession Crisis(minor,97y,political); The Migration(major,63y,demographic); The Purge(major,29y,occupation_infiltration); The Arcane Incident(minor,19y,magical)
    PAGE: [Summary/Plot Hooks] Someone has been leaving anonymous notes in their office pointing to a colleague's corruption. The notes are accurate.

### rr3-village-insurgency-rand-0
    tier village pop 93 · crisis insurgency · prosperity Struggling · route river · terrain coastal
    powers 2: People's Council[government 53]; Elder Council[government 47] · govt 
    houses (12) key: Mill; Parish church; Priest (resident)
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Salted fish","Smoked seafood","Fish oil","Reeds and thatch","Coal","Waterfowl","Healing waters (bottled)","Pilgrim hospitality"] imports ["Route maps and intelligence","Incense and votive candles","Cordage, canvas, and vessel-maintenance supplies","Fine porcelain and lacquerware"]
    history: The Purge(major,135y,occupation_infiltration); The Occupation(major,97y,exile_return); The Succession Crisis(major,61y,political); The Arcane Incident(minor,52y,magical); The Economic Divide(major,28y,economic)
    PAGE: [Summary/Plot Hooks] Someone has been leaving anonymous notes in their office pointing to a colleague's corruption. The notes are accurate.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] Someone has been leaving anonymous notes in their office pointing to a colleague's corruption. The notes are accurate.

## A05 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs tier ≥ village (new) · prints in 239 towns (village,town,city,metropolis)

### r2r-metropolis-14
    tier metropolis pop 271164 · crisis under_siege · prosperity Struggling · route crossroads · terrain plains
    powers 8: High Theocratic Council[religious 24]; Religious Authorities[religious 23]; Military/Guard[military 13]; War Council[military 12]; Arcane Orders[magic 6]; Noble Houses[noble 5]; Craft Guilds[economy 4]; The Holy Compact[religious 13] · govt 
    houses (98) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Dressed stone (local quarry depleted)","Wool","Iron ore (local mines exhausted)","Luxury materials","Precious metals","Grain","Medicinal herbs","Paper","Paper materials","Coal and fuel (local seams exhausted)"]
    history: The Pilgrimage(minor,360y,religious); The Siege(major,349y,disaster); The Economic Divide(minor,302y,economic); The Religious Conflict(minor,258y,religious); The Arcane Incident(minor,223y,magical); The Occupation(catastrophic,180y,exile_return); The Great Fire(catastrophic,169y,disaster); The Migration(major,140y,demographic); The Scandal(major,95y,political); The Purge(major,84y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] A clerk in their office has been copying letters at night, and the copies have turned up in a rival's hands.

### r2s-famine-city-3
    tier city pop 11818 · crisis famine · prosperity Struggling · route crossroads · terrain plains
    powers 7: Religious Authorities[religious 21]; Noble Families[noble 16]; Military/Guard[military 16]; Noble Governorship[government 15]; Grain Holders[economy 11]; The Old Houses[noble 9]; The Holy Compact[religious 12] · govt 
    houses (69) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; Elder Grove Council; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Multiple adventurers' guilds
    food: sources [] failed null granary true · balance {"imp":11586} · exports ["Milled flour","Transit trade","Toll revenue","Coal","Raw wool","Livestock","Glassware","Books and manuscripts","Cavalry mounts","Draft horses","Processed textiles","Quality tools and weapons","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Medicinal herbs","Paper materials","Timber","Stone","Salt","Grain","Precious metals and bullion","Luxury textiles and exotic goods","Gemstones (local deposits exhausted)","Game and hides (local hunting grounds exhausted)"]
    history: The Interregnum(catastrophic,319y,political); The Crash(major,299y,economic); The Occupation(catastrophic,249y,exile_return); The Succession Crisis(major,239y,political); The Heresy Trials(minor,205y,religious); The Siege(major,164y,disaster); The Arcane Incident(minor,131y,magical); The Migration(major,117y,demographic); The Economic Divide(minor,84y,economic); The Great Fire(major,46y,disaster); The Purge(major,24y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] A clerk in their office has been copying letters at night, and the copies have turned up in a rival's hands.

### r2s-occupied-city-0
    tier city pop 5170 · crisis occupied · prosperity Poor · route crossroads · terrain plains
    powers 5: Occupation Authority[military 38]; Arcane Orders[magic 17]; Military City Council[military 15]; The Tower Alliance[magic 9]; The Shield Compact[military 21] · govt 
    houses (55) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Tailor's guild; Craft guilds (30-80); Parish churches (10-30); City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Multiple adventurers' guilds; Black market; Mages' guild
    food: sources [] failed null granary true · balance {"imp":4508} · exports ["Transit trade (taxed by occupation)","Toll revenue (taxed by occupation)","Medicinal herbs (taxed by occupation)","Alchemical reagents (taxed by occupation)","Wild honey (taxed by occupation)","Financial services (letters of credit)","Legal services (contracts, notarial)","Military contract services","Arcane services (identification, enchanting)","Alchemical trade (potions, reagents)"] imports ["Bulk grain (local fields depleted)","Luxury materials","Precious metals","Salt","Charcoal and fuel","Luxury textiles and exotic goods","Gemstones (local deposits exhausted)","Incense and votive candles","Horses and warhorse stock","Rune-worthy bone and antler"]
    history: The Siege(major,121y,disaster); The Succession Crisis(major,88y,political); The Wild Magic(minor,65y,magical); The Purge(major,10y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] A clerk in their office has been copying letters at night, and the copies have turned up in a rival's hands.

### rr3-village-insurgency-rand-0
    tier village pop 93 · crisis insurgency · prosperity Struggling · route river · terrain coastal
    powers 2: People's Council[government 53]; Elder Council[government 47] · govt 
    houses (12) key: Mill; Parish church; Priest (resident)
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Salted fish","Smoked seafood","Fish oil","Reeds and thatch","Coal","Waterfowl","Healing waters (bottled)","Pilgrim hospitality"] imports ["Route maps and intelligence","Incense and votive candles","Cordage, canvas, and vessel-maintenance supplies","Fine porcelain and lacquerware"]
    history: The Purge(major,135y,occupation_infiltration); The Occupation(major,97y,exile_return); The Succession Crisis(major,61y,political); The Arcane Incident(minor,52y,magical); The Economic Divide(major,28y,economic)
    PAGE: [Summary/Plot Hooks] A clerk in their office has been copying letters at night, and the copies have turned up in a rival's hands.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] A clerk in their office has been copying letters at night, and the copies have turned up in a rival's hands.

## A06 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs tier ≥ village (new) · prints in 261 towns (village,town,city,metropolis)

### r2r-metropolis-14
    tier metropolis pop 271164 · crisis under_siege · prosperity Struggling · route crossroads · terrain plains
    powers 8: High Theocratic Council[religious 24]; Religious Authorities[religious 23]; Military/Guard[military 13]; War Council[military 12]; Arcane Orders[magic 6]; Noble Houses[noble 5]; Craft Guilds[economy 4]; The Holy Compact[religious 13] · govt 
    houses (98) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Dressed stone (local quarry depleted)","Wool","Iron ore (local mines exhausted)","Luxury materials","Precious metals","Grain","Medicinal herbs","Paper","Paper materials","Coal and fuel (local seams exhausted)"]
    history: The Pilgrimage(minor,360y,religious); The Siege(major,349y,disaster); The Economic Divide(minor,302y,economic); The Religious Conflict(minor,258y,religious); The Arcane Incident(minor,223y,magical); The Occupation(catastrophic,180y,exile_return); The Great Fire(catastrophic,169y,disaster); The Migration(major,140y,demographic); The Scandal(major,95y,political); The Purge(major,84y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] Their deputy has started answering questions meant for them, and people have begun going to the deputy first.

### r2s-famine-metropolis-0
    tier metropolis pop 39834 · crisis famine · prosperity Struggling · route road · terrain mountain
    powers 8: Royal Authority[government 19]; Noble Houses[noble 17]; Military/Guard[military 15]; Thieves' Guild[criminal 14]; Grain Holders[economy 10]; Arcane Orders[magic 9]; Merchant Guilds[economy 7]; The Landed Bloc[noble 9] · govt 
    houses (93) key: Fish market; District markets (5-10); Multiple market squares; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild; Airship docking (high magic); Merchant guilds (50-100+); Docks/port facilities
    food: sources [] failed null granary true · balance {"imp":40878} · exports ["Transit trade","Toll revenue","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Planar travel information","News and information","Maps and charts","Glassware","Books and manuscripts","Legal services (contracts, notarial)","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Dressed stone (local quarry depleted)","Wool","Iron","Timber (local forests cleared)","Grain","Paper","Paper materials","Salt","Clay and raw materials","Wool, dairy, and livestock (local alpine pasture depleted)"]
    history: The Schism(minor,556y,political); The Occupation(major,518y,exile_return); The Plague Years(catastrophic,448y,disaster); The Siege(major,421y,disaster); The Arcane Incident(major,332y,magical); The Debt Crisis(major,282y,economic); The Succession Crisis(major,241y,political); The Migration(major,138y,demographic); The Purge(major,92y,occupation_infiltration); The Religious Conflict(minor,23y,religious)
    PAGE: [Summary/Plot Hooks] Their deputy has started answering questions meant for them, and people have begun going to the deputy first.

### r2s-occupied-town-0
    tier town pop 1580 · crisis occupied · prosperity Poor · route road · terrain hills
    powers 4: Occupation Authority[military 41]; Town Council[government 28]; Resistance Network[military 17]; Merchant Guilds[economy 14] · govt 
    houses (33) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Adventurers' charter hall; Hireling hall; Town walls; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":870} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)","Legal services (contracts, notarial)"] imports ["Wool","Iron","Grain","Salt","Livestock and dairy (local pastures depleted)","Quality weapons and armour","Incense and votive candles","Lorica segmentata fittings","Fine wine and amphorae"]
    history: The Succession Crisis(minor,97y,political); The Migration(major,63y,demographic); The Purge(major,29y,occupation_infiltration); The Arcane Incident(minor,19y,magical)
    PAGE: [Summary/Plot Hooks] Their deputy has started answering questions meant for them, and people have begun going to the deputy first.

### rr3-village-insurgency-rand-5
    tier village pop 170 · crisis insurgency · prosperity Struggling · route river · terrain riverside
    powers 2: People's Council[government 53]; Elder Council[government 47] · govt 
    houses (14) key: Mill; Sawmill; Parish church; Priest (resident)
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["River fish","Freshwater catch","Grain surplus","Milled flour","Healing waters (bottled)","Pilgrim hospitality","Salted fish","Smoked seafood","Baked goods"] imports ["Incense and votive candles","Cordage, canvas, and vessel-maintenance supplies","Fine wine and amphorae"]
    history: The Economic Divide(major,205y,economic); The Occupation(major,177y,exile_return); The Arcane Incident(minor,112y,magical); The Succession Crisis(major,66y,political); The Religious Conflict(major,44y,religious)
    PAGE: [Summary/Plot Hooks] Their deputy has started answering questions meant for them, and people have begun going to the deputy first.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] Their deputy has started answering questions meant for them, and people have begun going to the deputy first.

## A07 · src/data/npcData.js · NPC_FACTION_LOYALTY.government · needs tier ≥ village (new) · prints in 232 towns (town,city,metropolis,village)

### r2s-under_siege-metropolis-1
    tier metropolis pop 70862 · crisis under_siege · prosperity Struggling · route port · terrain coastal
    powers 7: Grand Military Council[military 32]; Military/Guard[military 26]; Noble Houses[noble 8]; War Council[military 8]; Arcane Orders[magic 7]; The Garrison Bloc[military 14]; The Shield Compact[military 5] · govt 
    houses (95) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Docks/port facilities; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Black market bazaar; Elder Grove Council
    food: sources ["fish"] failed null granary true · balance {"imp":0} · exports ["Ship passage (naval route only)","Financial services (letters of credit)","Legal services (contracts, notarial)","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Maritime services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Shipbuilding timber (coastal stands cleared)","Precious metals","Iron (weapons)","Grain","Paper","Paper materials","Luxury materials","Salt","Salted fish (local fishing grounds exhausted)","Arcane reagents and energy (local ley node exhausted)"]
    history: The Tyranny(major,681y,political); The Occupation(major,611y,exile_return); The Wild Magic(minor,468y,magical); The Siege(catastrophic,438y,disaster); The Purge(major,355y,occupation_infiltration); The Succession Crisis(minor,320y,political); The Arcane Incident(minor,226y,magical); The Migration(minor,78y,demographic); The Economic Divide(minor,57y,economic)
    PAGE: [Summary/Plot Hooks] Someone has forged their seal well enough to fool their own staff, and three orders went out under it before anyone noticed.

### r2s-famine-city-3
    tier city pop 11818 · crisis famine · prosperity Struggling · route crossroads · terrain plains
    powers 7: Religious Authorities[religious 21]; Noble Families[noble 16]; Military/Guard[military 16]; Noble Governorship[government 15]; Grain Holders[economy 11]; The Old Houses[noble 9]; The Holy Compact[religious 12] · govt 
    houses (69) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; Elder Grove Council; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Multiple adventurers' guilds
    food: sources [] failed null granary true · balance {"imp":11586} · exports ["Milled flour","Transit trade","Toll revenue","Coal","Raw wool","Livestock","Glassware","Books and manuscripts","Cavalry mounts","Draft horses","Processed textiles","Quality tools and weapons","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Medicinal herbs","Paper materials","Timber","Stone","Salt","Grain","Precious metals and bullion","Luxury textiles and exotic goods","Gemstones (local deposits exhausted)","Game and hides (local hunting grounds exhausted)"]
    history: The Interregnum(catastrophic,319y,political); The Crash(major,299y,economic); The Occupation(catastrophic,249y,exile_return); The Succession Crisis(major,239y,political); The Heresy Trials(minor,205y,religious); The Siege(major,164y,disaster); The Arcane Incident(minor,131y,magical); The Migration(major,117y,demographic); The Economic Divide(minor,84y,economic); The Great Fire(major,46y,disaster); The Purge(major,24y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] Someone has forged their seal well enough to fool their own staff, and three orders went out under it before anyone noticed.

### r2s-occupied-village-2
    tier village pop 386 · crisis occupied · prosperity Poor · route crossroads · terrain riverside
    powers 3: Merchant Guilds[economy 39]; Occupation Authority[military 32]; Household Council[government 29] · govt 
    houses (14) key: Fish market; Weekly market; Mill; Parish church; Priest (resident); Adventurers' charter hall
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":9} · exports ["River fish (taxed by occupation)","Freshwater catch (taxed by occupation)","Raw wool (taxed by occupation)","Livestock (taxed by occupation)","Transit trade (taxed by occupation)"] imports ["Replacement arms and basic equipment","Incense and votive candles","Bronze fittings and tools"]
    history: The Purge(major,16y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] Someone has forged their seal well enough to fool their own staff, and three orders went out under it before anyone noticed.

### r2s-occupied-village-3
    tier village pop 134 · crisis occupied · prosperity Struggling · route road · terrain hills
    powers 2: Occupation Authority[military 68]; Elder Council[government 32] · govt 
    houses (9) key: Mill; Parish church; Priest (resident)
    food: sources ["game"] failed null granary false · balance {"imp":22} · exports ["Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)","Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Herbal remedies (taxed by occupation)"] imports ["Salt","Iron arrowheads and spearheads"]
    history: The Religious Conflict(minor,103y,religious); The Plague Years(major,80y,disaster); The Economic Divide(major,55y,economic); The Migration(major,34y,political); The Purge(major,18y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] Someone has forged their seal well enough to fool their own staff, and three orders went out under it before anyone noticed.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Plot Hooks] Someone has forged their seal well enough to fool their own staff, and three orders went out under it before anyone noticed.

## A08 · src/data/npcData.js + npcGenerator.js · MILITARY_HOOKS_TRUE_OF_ANY_HOLDER (kept on a non-military holder under the crisis bias) · crisis maps to military; holder category ≠ military · prints in 367 towns (village,town,city,metropolis,hamlet,thorp)

### r2r-metropolis-14
    tier metropolis pop 271164 · crisis under_siege · prosperity Struggling · route crossroads · terrain plains
    powers 8: High Theocratic Council[religious 24]; Religious Authorities[religious 23]; Military/Guard[military 13]; War Council[military 12]; Arcane Orders[magic 6]; Noble Houses[noble 5]; Craft Guilds[economy 4]; The Holy Compact[religious 13] · govt 
    houses (98) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Dressed stone (local quarry depleted)","Wool","Iron ore (local mines exhausted)","Luxury materials","Precious metals","Grain","Medicinal herbs","Paper","Paper materials","Coal and fuel (local seams exhausted)"]
    history: The Pilgrimage(minor,360y,religious); The Siege(major,349y,disaster); The Economic Divide(minor,302y,economic); The Religious Conflict(minor,258y,religious); The Arcane Incident(minor,223y,magical); The Occupation(catastrophic,180y,exile_return); The Great Fire(catastrophic,169y,disaster); The Migration(major,140y,demographic); The Scandal(major,95y,political); The Purge(major,84y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] They've noticed the same group of faces at multiple locations where incidents occurred. No one else has.
      [Summary/Plot Hooks] They signed for supplies that never arrived, and the merchant who sold them is already spending the money.

### r2r-city-44
    tier city pop 2408 · crisis famine · prosperity Struggling · route river · terrain coastal
    powers 5: Religious Authorities[religious 31]; Military/Guard[military 24]; Ecclesiastical Council[religious 15]; The Order of the Watch[military 13]; The Holy Compact[religious 17] · govt 
    houses (39) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Barge and river transport company; Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Sawmill (commercial); Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Black market
    food: sources ["fish"] failed fish granary true · balance {"imp":2178} · exports ["Salted fish","Smoked seafood","Fish oil","Medicinal herbs","Wild honey","Sacred wood","Ritual components","Luxury manufactured goods","Fine metalwork and jewelry","Herbal remedies","Potions and elixirs","Rare spices and exotic dyes","Quality tools and weapons","Legal services (contracts, notarial)","Military contract services","Waterborne freight services (cargo, pilotage)"] imports ["Iron","Grain","Salt","Cut stone and masonry","Clay and raw materials","Luxury textiles and exotic goods","Coal and fuel (local seams exhausted)","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Fine pottery for libations"]
    history: The Heresy Trials(minor,120y,religious); The Religious Conflict(minor,112y,religious); The Great Construction(major,84y,economic); The Purge(major,83y,occupation_infiltration); The Siege(catastrophic,61y,disaster); The Succession Crisis(minor,31y,political); The Occupation(major,8y,exile_return)
    PAGE: [Summary/Plot Hooks] They've noticed the same group of faces at multiple locations where incidents occurred. No one else has.

### r2s-occupied-city-2
    tier city pop 13152 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 8: Corrupt City Council[criminal 21]; Merchant Guilds[economy 16]; Arcane Orders[magic 13]; Religious Authorities[religious 13]; Occupation Authority[military 13]; Craft Guilds[economy 11]; Military/Guard[military 5]; The Enlightened[magic 8] · govt 
    houses (90) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Barge and river transport company; Docks/port facilities; City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; Elder Grove Council; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Mages' guild; Teleportation circle; Multiple adventurers' guilds; Thieves' guild chapter; Whisper market; Black market
    food: sources ["fish"] failed null granary true · balance {"imp":11137} · exports ["Reeds and thatch (taxed by occupation)","Waterfowl (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Stone","Grain","Paper materials","Luxury materials","Precious metals","Capital","Charcoal and fuel","Preserved provisions","Clay and raw materials","Salted fish (local river fishery exhausted)"]
    history: The Migration(minor,128y,demographic); The Economic Divide(minor,122y,economic); The Siege(major,95y,disaster); The Purge(major,64y,occupation_infiltration); The Arcane Incident(minor,59y,magical); The Succession Crisis(minor,20y,political); The Occupation(major,19y,exile_return)
    PAGE: [Summary/Plot Hooks] They signed for supplies that never arrived, and the merchant who sold them is already spending the money.
      [Summary/Plot Hooks] They've noticed the same group of faces at multiple locations where incidents occurred. No one else has.

### rr3-thorp-recently_betrayed-rand-3
    tier thorp pop 10 · crisis recently_betrayed · prosperity Struggling · route river · terrain riverside
    powers 1: Elder Council[government 100] · govt 
    houses (6) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Sacred wood","Ritual components"] imports []
    history: The Succession Crisis(minor,64y,political); The Wild Magic(minor,28y,magical); The Great Construction(major,26y,economic); The Economic Divide(minor,7y,economic)
    PAGE: [Summary/Plot Hooks] They've noticed the same group of faces at multiple locations where incidents occurred. No one else has.

### r2r-metropolis-13
    tier metropolis pop 328486 · crisis none · prosperity Prosperous · route port · terrain coastal
    powers 7: City-State Council[government 37]; Military/Guard[military 19]; Noble Houses[noble 13]; Merchant Guilds[economy 10]; Craft Guilds[economy 8]; The Trade Compact[economy 6]; The Old Houses[noble 7] · govt 
    houses (93) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Docks/port facilities; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish"] failed null granary true · balance {"imp":329317} · exports ["Salted fish","Smoked seafood","Fish oil","Arcane reagents","Ship passage","Maritime trade access","Potions and elixirs","Maritime trade revenue","Ship construction","News and information","Maps and charts","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Maritime services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Shipbuilding timber (coastal stands cleared)","Herbs","Precious metals","Iron","Grain","Medicinal herbs","Paper","Paper materials","Luxury materials","Salt (local salt beds exhausted)"]
    history: The Guild War(minor,483y,economic); The Occupation(major,459y,exile_return); The Migration(major,361y,demographic); The Economic Divide(major,316y,economic); The Purge(major,254y,occupation_infiltration); The Succession Crisis(major,234y,political); The Religious Conflict(minor,150y,religious); The Wild Magic(minor,60y,magical); The Siege(catastrophic,59y,disaster)
    PAGE: [Summary/Plot Hooks] They've noticed the same group of faces at multiple locations where incidents occurred. No one else has.

## A10 · src/data/stressInstitutionEffects.js · indebted secret · indebted · prints in 53 towns (hamlet,village,town,city,metropolis,thorp)

### rr3-thorp-indebted-port-1
    tier thorp pop 6 · crisis indebted · prosperity Moderate · route port · terrain coastal
    powers 1: Headman's Authority[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Recovered artefacts"] imports []
    history: The Wild Magic(minor,257y,magical); The Guild War(minor,151y,economic); The Religious Conflict(minor,68y,religious)
    PAGE: [World/NPCs] Secret: The original contract that created the debt was based on projections they knew were false at the time of signing

### r2s-indebted-metropolis-1
    tier metropolis pop 145383 · crisis indebted · prosperity Comfortable · route river · terrain plains
    powers 8: Grand Guild Consortium[economy 31]; Military/Guard[military 15]; Merchant Guilds[economy 14]; Noble Houses[noble 11]; Craft Guilds[economy 9]; Arcane Orders[magic 9]; The Enlightened[magic 5]; The Highborn Circle[noble 6] · govt 
    houses (108) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; Guild consortium; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Whisper market; Assassins' guild; Airship docking (high magic); Thieves' guild (powerful)
    food: sources ["fish"] failed null granary true · balance {"imp":128282} · exports ["Healing waters (bottled)","Pilgrim hospitality","Raw wool","Livestock","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Planar travel information","News and information","Maps and charts","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Iron ore (local mines exhausted)","Timber (local forests cleared)","Medicinal herbs","Paper","Paper materials","Precious metals","Clay and raw materials","Herbs and forage (local gathering areas exhausted)"]
    history: The Pilgrimage(major,189y,religious); The Shortage(minor,186y,economic); The Migration(major,164y,demographic); The Interregnum(major,143y,political); The Crash(minor,119y,economic); The Purge(major,86y,occupation_infiltration); The Siege(major,83y,disaster); The Occupation(catastrophic,46y,exile_return); The Arcane Incident(major,33y,magical); The Land Dispute(major,20y,political)
    PAGE: [World/NPCs] Secret: The original contract that created the debt was based on projections they knew were false at the time of signing

### r2r-hamlet-38
    tier hamlet pop 47 · crisis indebted · prosperity Comfortable · route crossroads · terrain plains
    powers 1: Headman's Authority[government 100] · govt 
    houses (12) key: Access to external mill; Access to parish church
    food: sources ["game"] failed null granary false · balance {"imp":0} · exports ["Furs and pelts","Game meat","Hunting trophies","Transit trade","Toll revenue","Iron ore","Quality tools and weapons","Advanced weapons and armor"] imports ["Salt","Incense and votive candles"]
    history: The Occupation(catastrophic,92y,exile_return); The Iron Dispute(minor,53y,economic); The Economic Divide(minor,37y,economic); The Purge(major,27y,occupation_infiltration)
    PAGE: [World/NPCs] Secret: The original contract that created the debt was based on projections they knew were false at the time of signing

### r2r-village-38
    tier village pop 230 · crisis indebted · prosperity Poor · route river · terrain forest
    powers 2: Headman's Authority[government 64]; Creditor's Representative[other 36] · govt 
    houses (15) key: Mill; Parish church; Priest (resident)
    food: sources ["grain","livestock","fish"] failed null granary false · balance {"imp":0} · exports ["Raw wool","Livestock","Healing waters (bottled)","Pilgrim hospitality","Grain surplus","Milled flour","Baked goods","Preserved foods","Cavalry mounts","Draft horses"] imports ["Incense and votive candles","Rope, oakum, and rigging supplies","Gold and silver torcs"]
    history: The Economic Divide(major,15y,economic)
    PAGE: [World/NPCs] Secret: The original contract that created the debt was based on projections they knew were false at the time of signing

## A11 · src/data/stressInstitutionEffects.js · plague_onset secret · plague_onset · prints in 45 towns (town,city,village,metropolis,thorp,hamlet)

### rr3-thorp-plague_onset-rand-0
    tier thorp pop 8 · crisis plague_onset · prosperity Struggling · route road · terrain forest
    powers 1: Headman's Authority[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":2} · exports ["Reeds and thatch","Peat fuel","Waterfowl","Toll revenue","Pass transit trade"] imports ["Salt","Medicinal herbs"]
    history: The Great Construction(major,13y,economic)
    PAGE: [World/NPCs] Secret: Is hoarding medicines that should have been distributed, rationing them for their own use and close associates

### rr3-metropolis-plague_onset-rand-0
    tier metropolis pop 182668 · crisis plague_onset · prosperity Comfortable · route river · terrain riverside
    powers 8: Arcane Senate[magic 28]; Religious Authorities[religious 13]; Military/Guard[military 12]; Arcane Orders[magic 12]; Merchant Guilds[economy 11]; Craft Guilds[economy 10]; Quarantine Council[government 7]; The Garrison Bloc[military 7] · govt 
    houses (103) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Black market bazaar; Airship docking (high magic); Elder Grove Council
    food: sources ["fish"] failed null granary true · balance {"imp":174077} · exports ["Reeds and thatch","Waterfowl","Sacred wood","Ritual components","Medicinal herbs","Wild honey","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Wool","Iron","Timber (local forests cleared)","Stone","Grain","Paper","Paper materials","Luxury materials","Precious metals","Salted fish (local river fishery exhausted)"]
    history: The Crash(major,459y,economic); The Purge(major,395y,occupation_infiltration); The Guild War(major,373y,economic); The Uprising(catastrophic,317y,political); The Great Fire(catastrophic,290y,disaster); The Succession Crisis(minor,275y,political); The Occupation(catastrophic,232y,exile_return); The Economic Divide(major,211y,economic); The Flood(catastrophic,193y,disaster); The Arcane Incident(minor,138y,magical); The Siege(catastrophic,118y,disaster); The Migration(major,63y,demographic); The Religious Conflict(minor,35y,religious); The Plague Years(catastrophic,21y,disaster)
    PAGE: [World/NPCs] Secret: Is hoarding medicines that should have been distributed, rationing them for their own use and close associates

### r2r-town-37
    tier town pop 1272 · crisis plague_onset · prosperity Struggling · route port · terrain coastal
    powers 5: Thieves' Guild[criminal 29]; Feudal Appointee[noble 26]; Religious Authorities[religious 17]; Quarantine Council[government 15]; Landed Gentry[noble 13] · govt 
    houses (30) key: Weekly market; Market square; Docks/port facilities; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town hall; Town walls; Town watch; Adventurers' charter hall; Courthouse
    food: sources ["fish"] failed null granary true · balance {"imp":732} · exports ["Ship passage","Maritime trade access","Shipbuilding timber","Salted fish","Smoked seafood","Fish oil","Recovered artefacts","Barrels and containers","River craft","Cargo barges","Maritime trade revenue","Ship construction","Legal services (contracts, notarial)","Maritime services (cargo, pilotage)"] imports ["Iron","Grain","Medicinal herbs","Salt (local salt beds exhausted)","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Undeclared luxury silk","Incense and frankincense"]
    history: The Purge(major,122y,political); The Siege(major,100y,disaster); The Religious Conflict(minor,81y,religious); The Migration(minor,36y,demographic); The Occupation(catastrophic,21y,exile_return)
    PAGE: [World/NPCs] Secret: Is hoarding medicines that should have been distributed, rationing them for their own use and close associates

### r2r-city-19
    tier city pop 14810 · crisis plague_onset · prosperity Poor · route port · terrain coastal
    powers 7: Religious Authorities[religious 30]; Royal Authority[government 15]; Noble Families[noble 12]; Military/Guard[military 10]; Thieves' Guild[criminal 10]; The Peerage[noble 7]; The Faithful Assembly[religious 16] · govt 
    houses (77) key: Daily markets; Multiple market squares; Docks/port facilities; City granaries; Mills (2-5); Sawmill (commercial); Tailor's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Gambling halls; Multiple adventurers' guilds; Black market; Elder Grove Council
    food: sources ["fish"] failed null granary true · balance {"imp":13274} · exports ["Salted fish","Smoked seafood","Fish oil","Sea salt","Ship passage","Maritime trade access","Barrels and containers","Luxury manufactured goods","Fine metalwork and jewelry","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Paper materials","Iron","Grain","Medicinal herbs","Timber","Stone","Luxury materials","Luxury textiles and exotic goods","Recovered artefacts (local ruins exhausted)","Incense, ritual oil, sacred texts, and vestment cloth (bulk)"]
    history: The Flood(major,379y,disaster); The Great Fire(major,342y,disaster); The Purge(major,282y,occupation_infiltration); The Heresy Trials(minor,210y,religious); The Tyranny(catastrophic,126y,political); The Occupation(catastrophic,96y,exile_return); The Siege(catastrophic,18y,disaster)
    PAGE: [World/NPCs] Secret: Is hoarding medicines that should have been distributed, rationing them for their own use and close associates

## A12 · src/data/stressInstitutionEffects.js · monster_pressure secret · monster_pressure · prints in 51 towns (hamlet,village,city,metropolis,town)

### r2s-monster_pressure-hamlet-3
    tier hamlet pop 48 · crisis monster_pressure · prosperity Poor · route road · terrain hills
    powers 1: Headman's Authority[government 100] · govt 
    houses (10) key: Access to external mill; Access to parish church
    food: sources ["grain"] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs","Wild honey","Toll revenue","Pass transit trade","Coal","Grain surplus"] imports ["Salt","Incense and votive candles"]
    history: The Great Fire(major,87y,disaster); The Succession Crisis(major,56y,political); The Great Harvest Compact(major,54y,economic); The Debt Crisis(major,36y,economic); The Purge(major,24y,occupation_infiltration)
    PAGE: [World/NPCs] Secret: The work they authorised six months ago disturbed a nesting site. The attacks started three weeks later

### rr3-metropolis-monster_pressure-rand-2
    tier metropolis pop 74412 · crisis monster_pressure · prosperity Moderate · route river · terrain coastal
    powers 6: Democratic assembly[government 24]; Military/Guard[military 23]; Religious Authorities[religious 20]; Noble Houses[noble 10]; The Martial Alliance[military 12]; The Clergy Alliance[religious 11] · govt 
    houses (85) key: Fish market; District markets (5-10); Multiple market squares; Barge and river transport company; State granary complex; Mills (2-5); Sawmill (commercial); Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Whisper market; Black market bazaar; Assassins' guild; Cobbler's guild; Multiple adventurers' guilds
    food: sources ["fish"] failed null granary true · balance {"imp":70515} · exports ["Salted fish","Smoked seafood","Fish oil","Iron ore","Weapons and armour","Raw wool","Livestock","Spellcasting (minor)","Magical identification","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Bulk grain (local fields depleted)","Stone","Medicinal herbs","Paper","Paper materials","Capital","Charcoal and fuel","Clay and raw materials","Luxury textiles and exotic goods","Ritual wood and herbs (ancient grove damaged)"]
    history: The Occupation(catastrophic,255y,exile_return); The Religious Conflict(minor,197y,religious); The Arcane Incident(major,78y,magical); The Purge(major,47y,occupation_infiltration)
    PAGE: [World/NPCs] Secret: The work they authorised six months ago disturbed a nesting site. The attacks started three weeks later

### r2r-hamlet-10
    tier hamlet pop 90 · crisis monster_pressure · prosperity Moderate · route port · terrain coastal
    powers 2: Military/Guard[military 59]; Free Elder Council[government 41] · govt 
    houses (16) key: Access to external mill; Access to parish church; Adventurers' charter hall; Palisade or earthworks; Citizen militia
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Sea salt","Preserved foods"] imports ["Replacement arms and basic equipment","Incense and votive candles"]
    history: The Succession Crisis(major,69y,political)
    PAGE: [World/NPCs] Secret: The work they authorised six months ago disturbed a nesting site. The attacks started three weeks later

### r2r-hamlet-27
    tier hamlet pop 96 · crisis monster_pressure · prosperity Poor · route port · terrain coastal
    powers 2: Military/Guard[military 57]; Elder Council[government 43] · govt 
    houses (18) key: Access to external mill; Access to parish church; Adventurers' charter hall; Palisade or earthworks; Citizen militia
    food: sources ["fish"] failed null granary false · balance {"imp":2} · exports ["Salted fish","Smoked seafood","Fish oil","Shipbuilding timber","Magical services","Barrels and containers","Potions and elixirs"] imports ["Quality weapons and armour","Incense and votive candles"]
    history: The Succession Crisis(minor,13y,political); The Arcane Incident(catastrophic,12y,magical)
    PAGE: [World/NPCs] Secret: The work they authorised six months ago disturbed a nesting site. The attacks started three weeks later

## A13 · src/data/stressInstitutionEffects.js · wartime secret (stakes gated) · wartime; needs prosperity ≥ comfortable (new) · prints in 12 towns (town,city,metropolis)

### rr3-town-wartime-port-1
    tier town pop 1128 · crisis wartime · prosperity Prosperous · route port · terrain coastal
    powers 4: Arcane Council[magic 34]; Religious Authorities[religious 28]; Merchant Guilds[economy 20]; War Council[military 18] · govt 
    houses (30) key: Weekly market; Market square; Carriers' guild; Docks/port facilities; Harbour master's office; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Teleportation circle
    food: sources [] failed null granary true · balance {"imp":641} · exports ["Legal services (contracts, notarial)","Waterborne freight services (cargo, pilotage)"] imports ["Iron","Grain","Warehousing and logistics services","Arcane reagents and energy (local ley node exhausted)","Incense and votive candles","Cordage, tar, timber fittings, and bulk vessel supplies","Shamanic herbs and bones","Felt for yurt-shrines"]
    history: The Arcane Incident(catastrophic,50y,magical); The Wild Magic(minor,45y,magical); The Occupation(major,25y,exile_return)
    PAGE: [World/NPCs] Secret: Took a private share of the war contracts that made the settlement rich, routed through a merchant house that does not exist on paper

### rr3-metropolis-wartime-rand-1
    tier metropolis pop 163257 · crisis wartime · prosperity Comfortable · route river · terrain riverside
    powers 8: Military/Guard[military 24]; City-State Council[government 22]; Religious Authorities[religious 18]; Merchant Guilds[economy 12]; Craft Guilds[economy 8]; War Council[military 7]; Noble Houses[noble 6]; The Landed Bloc[noble 3] · govt 
    houses (97) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":151217} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Quarried stone","Medicinal herbs","Wild honey","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Iron","Grain","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Luxury textiles and exotic goods","Game and hides (local hunting grounds exhausted)","Coal and fuel (local seams exhausted)"]
    history: The Shortage(minor,487y,economic); The Schism(minor,438y,political); The Economic Divide(minor,353y,economic); The Siege(catastrophic,282y,disaster); The Migration(major,248y,demographic); The Uprising(major,133y,political); The Religious Conflict(major,77y,religious)
    PAGE: [World/NPCs] Secret: Took a private share of the war contracts that made the settlement rich, routed through a merchant house that does not exist on paper

### r2s-wartime-town-2
    tier town pop 1803 · crisis wartime · prosperity Comfortable · route road · terrain plains
    powers 4: Feudal Appointee[noble 32]; Military/Guard[military 24]; Landed Gentry[noble 22]; War Council[military 22] · govt 
    houses (37) key: Weekly market; Market square; Merchant guilds (3-8); Carriers' guild; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town hall; Town watch; Teleportation circle; Fish market; Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":620} · exports ["Toll revenue","Pass transit trade","Precious metals","Coal","Quality tools and weapons","Alchemical trade (potions, reagents)"] imports ["Wool","Iron ore (local mines exhausted)","Grain","Livestock and dairy (local pastures depleted)","Game and hides (local hunting grounds exhausted)","Incense, ritual oil, and vestment materials","Alchemical reagents and scribal supplies","War elephants and fodder","Dried rice and provisions"]
    history: The Arcane Incident(minor,225y,magical); The Occupation(catastrophic,178y,exile_return); The Purge(major,153y,occupation_infiltration); The Shortage(minor,126y,economic); The Economic Divide(minor,109y,economic); The Religious Conflict(minor,76y,religious); The Siege(catastrophic,33y,disaster); The Succession Crisis(major,28y,political)
    PAGE: [World/NPCs] Secret: Took a private share of the war contracts that made the settlement rich, routed through a merchant house that does not exist on paper

### r2s-wartime-city-0
    tier city pop 11560 · crisis wartime · prosperity Comfortable · route road · terrain hills
    powers 8: Military/Guard[military 20]; Noble Governorship[government 18]; Noble Families[noble 17]; Religious Authorities[religious 15]; War Council[military 10]; Arcane Orders[magic 7]; The Tower Alliance[magic 4]; The Peerage[noble 9] · govt 
    houses (81) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Mages' guild; Multiple adventurers' guilds; Whisper market; Black market; Gambling halls
    food: sources [] failed null granary true · balance {"imp":8699} · exports ["Raw wool","Livestock","Toll revenue","Pass transit trade","Reeds and thatch","Peat fuel","Waterfowl","Transit trade","Spellcasting (minor)","Magical identification","Cavalry mounts","Draft horses","Quality tools and weapons","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Iron","Stone","Grain","Medicinal herbs","Paper materials","Salt","Warehousing and logistics services","Clay and raw materials","Precious metals (local veins exhausted)","Herbs and forage (local gathering areas exhausted)"]
    history: The Purge(major,120y,occupation_infiltration); The Succession Crisis(major,84y,political); The Plague Years(catastrophic,61y,disaster); The Economic Divide(minor,27y,economic)
    PAGE: [World/NPCs] Secret: Took a private share of the war contracts that made the settlement rich, routed through a merchant house that does not exist on paper

## A14 · src/generators/economy/foodBalance.js · plagueFoodNote (fields) · plague_onset; foodSources[0] not fish/livestock/game · prints in 43 towns (thorp,hamlet,village,town,city,metropolis)

### rr3-thorp-plague_onset-rand-0
    tier thorp pop 8 · crisis plague_onset · prosperity Struggling · route road · terrain forest
    powers 1: Headman's Authority[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":2} · exports ["Reeds and thatch","Peat fuel","Waterfowl","Toll revenue","Pass transit trade"] imports ["Salt","Medicinal herbs"]
    history: The Great Construction(major,13y,economic)
    PAGE: [Systems/Outlook] The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.

### rr3-metropolis-plague_onset-rand-3
    tier metropolis pop 69384 · crisis plague_onset · prosperity Moderate · route crossroads · terrain plains
    powers 9: Religious Authorities[religious 32]; Grand Merchant Oligarchy[economy 14]; Military/Guard[military 12]; Thieves' Guild[criminal 12]; Quarantine Council[government 8]; Merchant Guilds[economy 7]; Craft Guilds[economy 7]; The Merchant Bloc[economy 4]; The Establishment[government 4] · govt 
    houses (96) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":66741} · exports ["Transit trade","Toll revenue","Rare spices and exotic dyes","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Fine textiles","Meals and drink","Preserved foods","Glassware","Books and manuscripts","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Dressed stone (local quarry depleted)","Wool","Iron ore (local mines exhausted)","Luxury materials","Precious metals","Grain","Medicinal herbs","Paper","Paper materials","Game and hides (local hunting grounds exhausted)"]
    history: The Religious Conflict(minor,218y,religious); The Purge(major,183y,occupation_infiltration); The Migration(minor,171y,political); The Economic Divide(major,134y,economic); The Plague Years(major,112y,disaster); The Siege(catastrophic,71y,disaster); The Flood(major,59y,disaster); The Succession Crisis(minor,20y,political)
    PAGE: [Systems/Outlook] The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.

### r2s-plague_onset-thorp-0
    tier thorp pop 14 · crisis plague_onset · prosperity Struggling · route road · terrain forest
    powers 1: Elder Council[government 100] · govt 
    houses (7) key: Access to external mill
    food: sources [] failed null granary false · balance {"imp":3} · exports ["Raw wool","Livestock","Sacred wood","Ritual components"] imports ["Salt","Medicinal herbs"]
    history: The Purge(major,106y,occupation_infiltration); The Flood(catastrophic,63y,disaster); The Schism(minor,21y,political)
    PAGE: [Summary/Overview] Life here runs mostly on the wool trade, and that trade is under strain. The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.
      [World/History] Life here runs mostly on the wool trade, and that trade is under strain. The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.

### r2s-plague_onset-thorp-2
    tier thorp pop 9 · crisis plague_onset · prosperity Poor · route crossroads · terrain riverside
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt","Medicinal herbs"]
    history: The Religious Conflict(major,16y,religious); The Great Construction(major,14y,economic)
    PAGE: [Summary/Overview] The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.
      [World/History] The sickness is spreading among those who work the fields, and the ones still at work face a short harvest and a hard winter.

## A15 · src/generators/economy/foodBalance.js · plagueFoodNote (boats) · plague_onset; foodSources[0] = fish · prints in 27 towns (thorp,town,city,metropolis,hamlet,village)

### rr3-thorp-plague_onset-rand-5
    tier thorp pop 6 · crisis plague_onset · prosperity Struggling · route port · terrain coastal
    powers 1: Elder Council[government 100] · govt 
    houses (6) key: Access to external mill
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports ["Salted fish","Smoked seafood","Fish oil","Recovered artefacts"] imports ["Medicinal herbs"]
    history: The Debt Crisis(major,113y,economic); The Occupation(major,84y,exile_return); The Schism(minor,43y,political)
    PAGE: [Systems/Outlook] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.

### rr3-metropolis-plague_onset-rand-0
    tier metropolis pop 182668 · crisis plague_onset · prosperity Comfortable · route river · terrain riverside
    powers 8: Arcane Senate[magic 28]; Religious Authorities[religious 13]; Military/Guard[military 12]; Arcane Orders[magic 12]; Merchant Guilds[economy 11]; Craft Guilds[economy 10]; Quarantine Council[government 7]; The Garrison Bloc[military 7] · govt 
    houses (103) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Black market bazaar; Airship docking (high magic); Elder Grove Council
    food: sources ["fish"] failed null granary true · balance {"imp":174077} · exports ["Reeds and thatch","Waterfowl","Sacred wood","Ritual components","Medicinal herbs","Wild honey","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Wool","Iron","Timber (local forests cleared)","Stone","Grain","Paper","Paper materials","Luxury materials","Precious metals","Salted fish (local river fishery exhausted)"]
    history: The Crash(major,459y,economic); The Purge(major,395y,occupation_infiltration); The Guild War(major,373y,economic); The Uprising(catastrophic,317y,political); The Great Fire(catastrophic,290y,disaster); The Succession Crisis(minor,275y,political); The Occupation(catastrophic,232y,exile_return); The Economic Divide(major,211y,economic); The Flood(catastrophic,193y,disaster); The Arcane Incident(minor,138y,magical); The Siege(catastrophic,118y,disaster); The Migration(major,63y,demographic); The Religious Conflict(minor,35y,religious); The Plague Years(catastrophic,21y,disaster)
    PAGE: [Summary/Overview] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.
      [World/History] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.

### r2r-thorp-41
    tier thorp pop 22 · crisis plague_onset · prosperity Struggling · route river · terrain forest
    powers 1: Elder Council[government 100] · govt 
    houses (12) key: Access to external mill; Wayside shrine; Access to parish church; Palisade
    food: sources ["fish","game"] failed null granary false · balance {"imp":6} · exports ["Healing waters (bottled)","Pilgrim hospitality"] imports ["Medicinal herbs"]
    history: The Siege(catastrophic,61y,disaster)
    PAGE: [Summary/Overview] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.
      [World/History] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.

### r2r-town-37
    tier town pop 1272 · crisis plague_onset · prosperity Struggling · route port · terrain coastal
    powers 5: Thieves' Guild[criminal 29]; Feudal Appointee[noble 26]; Religious Authorities[religious 17]; Quarantine Council[government 15]; Landed Gentry[noble 13] · govt 
    houses (30) key: Weekly market; Market square; Docks/port facilities; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town hall; Town walls; Town watch; Adventurers' charter hall; Courthouse
    food: sources ["fish"] failed null granary true · balance {"imp":732} · exports ["Ship passage","Maritime trade access","Shipbuilding timber","Salted fish","Smoked seafood","Fish oil","Recovered artefacts","Barrels and containers","River craft","Cargo barges","Maritime trade revenue","Ship construction","Legal services (contracts, notarial)","Maritime services (cargo, pilotage)"] imports ["Iron","Grain","Medicinal herbs","Salt (local salt beds exhausted)","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Undeclared luxury silk","Incense and frankincense"]
    history: The Purge(major,122y,political); The Siege(major,100y,disaster); The Religious Conflict(minor,81y,religious); The Migration(minor,36y,demographic); The Occupation(catastrophic,21y,exile_return)
    PAGE: [Summary/Overview] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.
      [World/History] The sickness is spreading among those who crew the boats, and the ones still at sea face a thin catch and a hard winter.

## A16 · src/generators/economy/foodBalance.js · plagueFoodNote (herds) · plague_onset; foodSources[0] = livestock · prints in 4 towns (village,hamlet)

### rr3-hamlet-plague_onset-rand-2
    tier hamlet pop 79 · crisis plague_onset · prosperity Moderate · route road · terrain plains
    powers 2: Household Council[government 64]; Quarantine Council[government 36] · govt 
    houses (11) key: Access to external mill; Access to parish church
    food: sources ["livestock"] failed null granary false · balance {"imp":2} · exports ["Raw wool","Livestock","Transit trade","Toll revenue","Coal"] imports ["Salt","Medicinal herbs","Incense and votive candles"]
    history: The Great Fire(catastrophic,26y,disaster)
    PAGE: [Systems/Outlook] The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.

### r2r-village-50
    tier village pop 386 · crisis plague_onset · prosperity Struggling · route road · terrain mountain
    powers 3: Religious Authorities[religious 38]; Headman's Authority[government 34]; Military/Guard[military 28] · govt 
    houses (14) key: Mill; Parish church; Priest (resident); Citizen militia
    food: sources ["livestock"] failed null granary false · balance {"imp":153} · exports ["Raw wool","Live sheep","Livestock","Transit trade","Toll revenue","Barrels and containers","Finished clothing","Dyed cloth"] imports ["Salt","Medicinal herbs","Raw cloth","Sandalwood and camphor"]
    history: The Flood(major,25y,disaster); The Great Construction(major,19y,economic)
    PAGE: [Summary/Overview] Life here runs mostly on the wool trade, and that trade is under strain. The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.
      [World/History] Life here runs mostly on the wool trade, and that trade is under strain. The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.

### r2s-plague_onset-hamlet-3
    tier hamlet pop 97 · crisis plague_onset · prosperity Struggling · route road · terrain hills
    powers 1: Feudal Stewardship[government 100] · govt 
    houses (10) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources ["livestock"] failed null granary false · balance {"imp":19} · exports ["Sacred wood","Ritual components","Raw wool","Livestock"] imports ["Salt","Medicinal herbs","Incense and votive candles"]
    history: The Siege(major,109y,disaster); The Religious Conflict(major,76y,religious); The Purge(major,44y,occupation_infiltration); The Migration(minor,8y,demographic)
    PAGE: [Summary/Overview] Life here runs mostly on the timber trade, and that trade is under strain. The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.
      [World/History] Life here runs mostly on the timber trade, and that trade is under strain. The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.

### rr3-village-plague_onset-rand-1
    tier village pop 249 · crisis plague_onset · prosperity Struggling · route crossroads · terrain riverside
    powers 2: Religious Authorities[religious 75]; Elder Council[government 25] · govt 
    houses (15) key: Fish market; Mill; Parish church; Priest (resident)
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":44} · exports ["River fish","Freshwater catch","Raw wool","Livestock","Leather goods","Transit trade","Toll revenue","Salted fish","Smoked seafood"] imports ["Medicinal herbs","Incense and votive candles","Incense and ritual oil"]
    history: The Purge(major,121y,occupation_infiltration); The Interregnum(catastrophic,95y,political); The Occupation(major,73y,exile_return); The Siege(major,37y,disaster); The Religious Conflict(minor,21y,religious)
    PAGE: [Summary/Overview] Life here runs mostly on the fish trade, and that trade is under strain. The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.
      [Systems/Outlook] The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.
      [World/History] Life here runs mostly on the fish trade, and that trade is under strain. The sickness is spreading among those who tend the herds, and the ones still at work face a lean year and a hard winter.

## A17 · src/generators/economy/foodBalance.js · plagueFoodNote (hunt) · plague_onset; foodSources[0] = game · prints in 2 towns (thorp,village)

### rr3-thorp-plague_onset-rand-3
    tier thorp pop 16 · crisis plague_onset+famine · prosperity Struggling · route isolated · terrain forest
    powers 1: Household Council[government 100] · govt 
    houses (6) key: Access to external mill
    food: sources ["game"] failed game granary false · balance {"imp":0} · exports [] imports []
    history: 
    PAGE: [Systems/Outlook] The sickness is spreading among those who hunt, and the ones still out face a lean season and a hard winter.

### rr3-village-plague_onset-rand-5
    tier village pop 94 · crisis plague_onset · prosperity Struggling · route isolated · terrain forest
    powers 2: Religious Authorities[religious 63]; Household Council[government 37] · govt 
    houses (11) key: Mill; Parish church; Priest (resident); Palisade or earthworks; Citizen militia
    food: sources ["game"] failed null granary false · balance {"imp":9} · exports [] imports ["Replacement arms and basic equipment","Incense and votive candles"]
    history: The Heresy Trials(minor,178y,religious); The Economic Divide(minor,148y,economic); The Siege(major,91y,disaster); The Purge(major,74y,occupation_infiltration); The Succession Crisis(major,29y,political)
    PAGE: [Systems/Outlook] The sickness is spreading among those who hunt, and the ones still out face a lean season and a hard winter.

## A18 · src/generators/economy/foodBalance.js · crisis food issue title (new label) · occupied or mass_migration arrivals note; rounded deficit ≤ 0 · prints in 47 towns (thorp,village,town,hamlet,metropolis,city)

### r2r-thorp-1
    tier thorp pop 30 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Occupation Authority[military 57]; Elder Council[government 43] · govt 
    houses (11) key: Access to external mill; Access to parish church; Palisade
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)","Contraband goods (transit) (taxed by occupation)"] imports []
    history: The Economic Divide(major,208y,economic); The Purge(major,179y,occupation_infiltration); The Uprising(major,39y,political)
    PAGE: [Systems/Outlook] Crisis Adding Mouths to Feed

### r2s-mass_migration-thorp-3
    tier thorp pop 7 · crisis mass_migration · prosperity Poor · route road · terrain plains
    powers 1: Headman's Authority[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Toll revenue","Pass transit trade"] imports ["Salt"]
    history: The Succession Crisis(major,125y,political); The Iron Dispute(minor,111y,economic); The Pilgrimage(minor,103y,religious); The Migration(major,12y,demographic)
    PAGE: [Systems/Outlook] Crisis Adding Mouths to Feed

### r2s-mass_migration-metropolis-3
    tier metropolis pop 248369 · crisis mass_migration · prosperity Comfortable · route road · terrain plains
    powers 8: Grand Military Council[military 22]; Military/Guard[military 16]; Religious Authorities[religious 15]; Noble Houses[noble 12]; Merchant Guilds[economy 11]; Arcane Orders[magic 11]; Craft Guilds[economy 7]; The Guild Alliance[economy 6] · govt 
    houses (104) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Whisper market; Black market bazaar; Airship docking (high magic); Docks/port facilities
    food: sources [] failed null granary true · balance {"imp":252628} · exports ["Transit trade","Toll revenue","Reeds and thatch","Waterfowl","Raw gemstones","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Planar travel information","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Wool","Stone","Iron","Grain","Medicinal herbs","Paper","Paper materials","Clay and raw materials","Luxury textiles and exotic goods","Livestock and dairy (local pastures depleted)"]
    history: The Uprising(catastrophic,533y,political); The Guild War(minor,492y,economic); The Land Dispute(major,480y,political); The Shortage(major,396y,economic); The Schism(minor,357y,political); The Siege(catastrophic,331y,disaster); The Heresy Trials(major,317y,religious); The Wild Magic(major,283y,magical); The Economic Divide(major,253y,economic); The Great Fire(catastrophic,241y,disaster); The Migration(minor,197y,demographic); The Arcane Incident(minor,137y,magical); The Occupation(major,122y,exile_return); The Succession Crisis(minor,91y,political); The Religious Conflict(minor,78y,religious); The Purge(major,11y,occupation_infiltration)
    PAGE: [Systems/Outlook] Crisis Adding Mouths to Feed

### r2r-thorp-27
    tier thorp pop 25 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Household Council[government 51]; Occupation Authority[military 49] · govt 
    houses (9) key: Access to external mill; Access to parish church; Palisade
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)"] imports []
    history: The Siege(major,201y,disaster); The Schism(minor,136y,political); The Purge(major,52y,occupation_infiltration)
    PAGE: [Systems/Outlook] Crisis Adding Mouths to Feed

## A19 · src/generators/economy/foodBalance.js · crisis food issue title (re-keyed on the published deficit) · rounded deficit > 0 · prints in 526 towns (thorp,hamlet,village,town,city,metropolis)

### r2s-occupied-thorp-3
    tier thorp pop 18 · crisis occupied · prosperity Poor · route road · terrain plains
    powers 2: Occupation Authority[military 52]; Household Council[government 48] · govt 
    houses (9) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":1} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)"] imports ["Salt"]
    history: The Succession Crisis(minor,152y,political); The Purge(major,128y,occupation_infiltration); The Debt Crisis(major,57y,economic)
    PAGE: [Systems/Outlook] Crisis Cutting the Food Supply

### r2s-occupied-hamlet-3
    tier hamlet pop 43 · crisis occupied · prosperity Poor · route road · terrain riverside
    powers 2: Headman's Authority[government 54]; Occupation Authority[military 46] · govt 
    houses (11) key: Access to external mill; Access to parish church; Adventurers' charter hall
    food: sources ["fish","game"] failed null granary false · balance {"imp":1} · exports ["River fish (taxed by occupation)","Freshwater catch (taxed by occupation)","Sacred wood (taxed by occupation)","Ritual components (taxed by occupation)","Coal (taxed by occupation)"] imports ["Replacement arms and basic equipment","Incense and votive candles"]
    history: The Purge(major,26y,occupation_infiltration)
    PAGE: [Systems/Outlook] Crisis Cutting the Food Supply

### r2s-wartime-hamlet-0
    tier hamlet pop 75 · crisis wartime · prosperity Moderate · route road · terrain riverside
    powers 2: Free Elder Council[government 62]; War Council[military 38] · govt 
    houses (14) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports ["Coal","Sacred wood","Ritual components"] imports ["Salt","Incense and votive candles"]
    history: The Guild War(minor,33y,economic)
    PAGE: [Systems/Outlook] Crisis Cutting the Food Supply

### rr3-hamlet-occupied-rand-3
    tier hamlet pop 33 · crisis occupied · prosperity Poor · route crossroads · terrain plains
    powers 2: Free Elder Council[government 55]; Occupation Authority[military 45] · govt 
    houses (13) key: Access to external mill; Access to parish church; Palisade or earthworks; Citizen militia
    food: sources ["game"] failed null granary false · balance {"imp":2} · exports ["Furs and pelts (taxed by occupation)","Game meat (taxed by occupation)","Hunting trophies (taxed by occupation)","Transit trade (taxed by occupation)","Toll revenue (taxed by occupation)"] imports ["Salt","Replacement arms and basic equipment","Incense and votive candles"]
    history: The Religious Conflict(major,17y,religious)
    PAGE: [Systems/Outlook] Crisis Cutting the Food Supply

## A19b · src/generators/economy/foodBalance.js · crisis food issue title (re-keyed) · rounded deficit ≤ 0, not a mouths note · prints in 29 towns (thorp,hamlet,village,town,city,metropolis)

### r2s-plague_onset-thorp-2
    tier thorp pop 9 · crisis plague_onset · prosperity Poor · route crossroads · terrain riverside
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt","Medicinal herbs"]
    history: The Religious Conflict(major,16y,religious); The Great Construction(major,14y,economic)
    PAGE: [Systems/Outlook] Crisis Thinning the Harvest

### r2s-plague_onset-thorp-3
    tier thorp pop 15 · crisis plague_onset · prosperity Comfortable · route road · terrain plains
    powers 1: Household Council[government 100] · govt 
    houses (7) key: Access to external mill
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt","Medicinal herbs"]
    history: The Crash(major,208y,economic); The Succession Crisis(minor,44y,political)
    PAGE: [Systems/Outlook] Crisis Thinning the Harvest

### r2s-plague_onset-hamlet-0
    tier hamlet pop 25 · crisis plague_onset · prosperity Poor · route crossroads · terrain plains
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources ["grain"] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue","Furs and pelts"] imports ["Salt","Medicinal herbs","Incense and votive candles"]
    history: The Economic Divide(minor,20y,economic)
    PAGE: [Systems/Outlook] Crisis Thinning the Harvest

### r2s-slave_revolt-village-3
    tier village pop 171 · crisis slave_revolt · prosperity Struggling · route river · terrain riverside
    powers 2: Military/Guard[military 77]; Headman's Authority[government 23] · govt 
    houses (13) key: Mill; Parish church; Priest (resident); Palisade or earthworks; Citizen militia
    food: sources ["fish","mill"] failed null granary false · balance {"imp":4} · exports ["Milled flour","Pottery and ceramics","Sacred wood","Ritual components","Coal","Healing waters (bottled)","Pilgrim hospitality","Wild honey","Candles and wax","Barrels and containers"] imports ["Replacement arms and basic equipment","Iron arrowheads and spearheads"]
    history: The Siege(catastrophic,114y,disaster); The Economic Divide(major,50y,economic); The Migration(minor,15y,demographic)
    PAGE: [Systems/Outlook] Crisis Thinning the Harvest

## A20 · src/generators/economy/foodBalance.js · priorityNote (new) · mouths note; deficit ≤ 0; production ≥ need · prints in 22 towns (thorp,hamlet,village)

### r2r-thorp-1
    tier thorp pop 30 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Occupation Authority[military 57]; Elder Council[government 43] · govt 
    houses (11) key: Access to external mill; Access to parish church; Palisade
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)","Contraband goods (transit) (taxed by occupation)"] imports []
    history: The Economic Divide(major,208y,economic); The Purge(major,179y,occupation_infiltration); The Uprising(major,39y,political)
    PAGE: (NOT ON THE PAGE)

### r2s-mass_migration-thorp-3
    tier thorp pop 7 · crisis mass_migration · prosperity Poor · route road · terrain plains
    powers 1: Headman's Authority[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Toll revenue","Pass transit trade"] imports ["Salt"]
    history: The Succession Crisis(major,125y,political); The Iron Dispute(minor,111y,economic); The Pilgrimage(minor,103y,religious); The Migration(major,12y,demographic)
    PAGE: (NOT ON THE PAGE)

### rr3-village-occupied-rand-3
    tier village pop 383 · crisis occupied · prosperity Poor · route crossroads · terrain plains
    powers 3: Merchant Guilds[economy 38]; Elder Council[government 32]; Occupation Authority[military 30] · govt 
    houses (21) key: Fish market; Weekly market; Carriers' hiring hall; Mill; Parish church; Priest (resident)
    food: sources ["grain","livestock"] failed null granary false · balance {"imp":0} · exports ["Raw wool (taxed by occupation)","Livestock (taxed by occupation)","Transit trade (taxed by occupation)","Toll revenue (taxed by occupation)"] imports ["Salt","Warehousing and logistics services","Amphora and storage vessels"]
    history: The Migration(major,8y,demographic)
    PAGE: (NOT ON THE PAGE)

### r2r-thorp-27
    tier thorp pop 25 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Household Council[government 51]; Occupation Authority[military 49] · govt 
    houses (9) key: Access to external mill; Access to parish church; Palisade
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)"] imports []
    history: The Siege(major,201y,disaster); The Schism(minor,136y,political); The Purge(major,52y,occupation_infiltration)
    PAGE: (NOT ON THE PAGE)

## A21 · src/generators/economy/foodBalance.js · priorityNote (new) · mouths note; deficit ≤ 0; production < need · prints in 25 towns (village,town,thorp,metropolis,hamlet,city)

### r2s-occupied-thorp-0
    tier thorp pop 13 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Household Council[government 51]; Occupation Authority[military 49] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports ["River fish (taxed by occupation)","Freshwater catch (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)"] imports []
    history: The Guild War(major,68y,economic); The Migration(minor,5y,demographic)
    PAGE: (NOT ON THE PAGE)

### rr3-thorp-mass_migration-rand-1
    tier thorp pop 9 · crisis mass_migration · prosperity Poor · route road · terrain hills
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt"]
    history: The Heresy Trials(minor,93y,religious); The Migration(minor,71y,demographic); The Arcane Incident(minor,32y,magical)
    PAGE: (NOT ON THE PAGE)

### r2s-mass_migration-metropolis-3
    tier metropolis pop 248369 · crisis mass_migration · prosperity Comfortable · route road · terrain plains
    powers 8: Grand Military Council[military 22]; Military/Guard[military 16]; Religious Authorities[religious 15]; Noble Houses[noble 12]; Merchant Guilds[economy 11]; Arcane Orders[magic 11]; Craft Guilds[economy 7]; The Guild Alliance[economy 6] · govt 
    houses (104) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Whisper market; Black market bazaar; Airship docking (high magic); Docks/port facilities
    food: sources [] failed null granary true · balance {"imp":252628} · exports ["Transit trade","Toll revenue","Reeds and thatch","Waterfowl","Raw gemstones","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Planar travel information","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Wool","Stone","Iron","Grain","Medicinal herbs","Paper","Paper materials","Clay and raw materials","Luxury textiles and exotic goods","Livestock and dairy (local pastures depleted)"]
    history: The Uprising(catastrophic,533y,political); The Guild War(minor,492y,economic); The Land Dispute(major,480y,political); The Shortage(major,396y,economic); The Schism(minor,357y,political); The Siege(catastrophic,331y,disaster); The Heresy Trials(major,317y,religious); The Wild Magic(major,283y,magical); The Economic Divide(major,253y,economic); The Great Fire(catastrophic,241y,disaster); The Migration(minor,197y,demographic); The Arcane Incident(minor,137y,magical); The Occupation(major,122y,exile_return); The Succession Crisis(minor,91y,political); The Religious Conflict(minor,78y,religious); The Purge(major,11y,occupation_infiltration)
    PAGE: (NOT ON THE PAGE)

### r2r-village-28
    tier village pop 249 · crisis mass_migration · prosperity Struggling · route road · terrain hills
    powers 3: Religious Authorities[religious 47]; Elder Council[government 28]; Military Party[military 25] · govt 
    houses (14) key: Fish market; Mill; Parish church; Priest (resident); Adventurers' charter hall
    food: sources ["game"] failed null granary false · balance {"imp":27} · exports ["Sacred wood","Ritual components","Medicinal herbs","Wild honey","Coal"] imports ["Salt","Incense and votive candles","Sandalwood and camphor"]
    history: The Purge(major,155y,occupation_infiltration); The Migration(minor,134y,demographic); The Succession Crisis(minor,89y,political); The Pilgrimage(major,69y,religious); The Occupation(catastrophic,34y,exile_return)
    PAGE: (NOT ON THE PAGE)

## A22 · src/generators/economy/foodBalance.js · priorityNote (new) · harvest note; deficit ≤ 0; production < need · prints in 14 towns (thorp,village,town,city,hamlet,metropolis)

### rr3-thorp-wartime-port-0
    tier thorp pop 5 · crisis wartime · prosperity Struggling · route port · terrain coastal
    powers 1: Household Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports [] imports []
    history: The Debt Crisis(major,54y,economic); The Arcane Incident(catastrophic,54y,magical)
    PAGE: (NOT ON THE PAGE)

### rr3-metropolis-wartime-rand-1
    tier metropolis pop 163257 · crisis wartime · prosperity Comfortable · route river · terrain riverside
    powers 8: Military/Guard[military 24]; City-State Council[government 22]; Religious Authorities[religious 18]; Merchant Guilds[economy 12]; Craft Guilds[economy 8]; War Council[military 7]; Noble Houses[noble 6]; The Landed Bloc[noble 3] · govt 
    houses (97) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":151217} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Quarried stone","Medicinal herbs","Wild honey","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Iron","Grain","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Luxury textiles and exotic goods","Game and hides (local hunting grounds exhausted)","Coal and fuel (local seams exhausted)"]
    history: The Shortage(minor,487y,economic); The Schism(minor,438y,political); The Economic Divide(minor,353y,economic); The Siege(catastrophic,282y,disaster); The Migration(major,248y,demographic); The Uprising(major,133y,political); The Religious Conflict(major,77y,religious)
    PAGE: (NOT ON THE PAGE)

### r2s-plague_onset-thorp-3
    tier thorp pop 15 · crisis plague_onset · prosperity Comfortable · route road · terrain plains
    powers 1: Household Council[government 100] · govt 
    houses (7) key: Access to external mill
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt","Medicinal herbs"]
    history: The Crash(major,208y,economic); The Succession Crisis(minor,44y,political)
    PAGE: (NOT ON THE PAGE)

### r2s-slave_revolt-village-3
    tier village pop 171 · crisis slave_revolt · prosperity Struggling · route river · terrain riverside
    powers 2: Military/Guard[military 77]; Headman's Authority[government 23] · govt 
    houses (13) key: Mill; Parish church; Priest (resident); Palisade or earthworks; Citizen militia
    food: sources ["fish","mill"] failed null granary false · balance {"imp":4} · exports ["Milled flour","Pottery and ceramics","Sacred wood","Ritual components","Coal","Healing waters (bottled)","Pilgrim hospitality","Wild honey","Candles and wax","Barrels and containers"] imports ["Replacement arms and basic equipment","Iron arrowheads and spearheads"]
    history: The Siege(catastrophic,114y,disaster); The Economic Divide(major,50y,economic); The Migration(minor,15y,demographic)
    PAGE: (NOT ON THE PAGE)

## A23 · src/generators/economy/foodBalance.js · priorityNote (re-keyed) · harvest note; deficit ≤ 0; production ≥ need · prints in 15 towns (thorp,hamlet)

### r2s-plague_onset-thorp-2
    tier thorp pop 9 · crisis plague_onset · prosperity Poor · route crossroads · terrain riverside
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt","Medicinal herbs"]
    history: The Religious Conflict(major,16y,religious); The Great Construction(major,14y,economic)
    PAGE: (NOT ON THE PAGE)

### r2s-plague_onset-hamlet-0
    tier hamlet pop 25 · crisis plague_onset · prosperity Poor · route crossroads · terrain plains
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources ["grain"] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue","Furs and pelts"] imports ["Salt","Medicinal herbs","Incense and votive candles"]
    history: The Economic Divide(minor,20y,economic)
    PAGE: (NOT ON THE PAGE)

### rr3-thorp-slave_revolt-rand-3
    tier thorp pop 12 · crisis slave_revolt · prosperity Struggling · route crossroads · terrain plains
    powers 1: Household Council[government 100] · govt 
    houses (8) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Raw wool","Livestock","Transit trade","Toll revenue"] imports ["Salt"]
    history: The Occupation(catastrophic,285y,exile_return); The Succession Crisis(major,118y,political); The Religious Conflict(major,20y,religious)
    PAGE: (NOT ON THE PAGE)

### rr3-hamlet-slave_revolt-rand-4
    tier hamlet pop 91 · crisis slave_revolt · prosperity Struggling · route road · terrain plains
    powers 1: Headman's Authority[government 100] · govt 
    houses (11) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs","Wild honey","Toll revenue","Pass transit trade"] imports ["Salt","Incense and votive candles"]
    history: The Religious Conflict(major,59y,religious)
    PAGE: (NOT ON THE PAGE)

## A24 · src/generators/economy/foodBalance.js · priorityNote (re-keyed) · rounded deficit > 0 · prints in 526 towns (thorp,hamlet,village,town,city,metropolis)

### r2s-occupied-thorp-3
    tier thorp pop 18 · crisis occupied · prosperity Poor · route road · terrain plains
    powers 2: Occupation Authority[military 52]; Household Council[government 48] · govt 
    houses (9) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":1} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Toll revenue (taxed by occupation)","Pass transit trade (taxed by occupation)"] imports ["Salt"]
    history: The Succession Crisis(minor,152y,political); The Purge(major,128y,occupation_infiltration); The Debt Crisis(major,57y,economic)
    PAGE: (NOT ON THE PAGE)

### r2s-occupied-hamlet-3
    tier hamlet pop 43 · crisis occupied · prosperity Poor · route road · terrain riverside
    powers 2: Headman's Authority[government 54]; Occupation Authority[military 46] · govt 
    houses (11) key: Access to external mill; Access to parish church; Adventurers' charter hall
    food: sources ["fish","game"] failed null granary false · balance {"imp":1} · exports ["River fish (taxed by occupation)","Freshwater catch (taxed by occupation)","Sacred wood (taxed by occupation)","Ritual components (taxed by occupation)","Coal (taxed by occupation)"] imports ["Replacement arms and basic equipment","Incense and votive candles"]
    history: The Purge(major,26y,occupation_infiltration)
    PAGE: (NOT ON THE PAGE)

### r2s-wartime-hamlet-0
    tier hamlet pop 75 · crisis wartime · prosperity Moderate · route road · terrain riverside
    powers 2: Free Elder Council[government 62]; War Council[military 38] · govt 
    houses (14) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports ["Coal","Sacred wood","Ritual components"] imports ["Salt","Incense and votive candles"]
    history: The Guild War(minor,33y,economic)
    PAGE: (NOT ON THE PAGE)

### rr3-hamlet-occupied-rand-3
    tier hamlet pop 33 · crisis occupied · prosperity Poor · route crossroads · terrain plains
    powers 2: Free Elder Council[government 55]; Occupation Authority[military 45] · govt 
    houses (13) key: Access to external mill; Access to parish church; Palisade or earthworks; Citizen militia
    food: sources ["game"] failed null granary false · balance {"imp":2} · exports ["Furs and pelts (taxed by occupation)","Game meat (taxed by occupation)","Hunting trophies (taxed by occupation)","Transit trade (taxed by occupation)","Toll revenue (taxed by occupation)"] imports ["Salt","Replacement arms and basic equipment","Incense and votive candles"]
    history: The Religious Conflict(major,17y,religious)
    PAGE: (NOT ON THE PAGE)

## A25 · src/generators/economy/foodBalance.js · import-dependence plot hook (new), category 'Scarce Food' · deficit% > importDependent cut; no import coverage or no channel label · prints in 26 towns (thorp,hamlet,village,metropolis,city)

### r2s-under_siege-hamlet-2
    tier hamlet pop 94 · crisis under_siege · prosperity Struggling · route river · terrain plains
    powers 1: Headman's Authority[government 100] · govt 
    houses (11) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)","Incense and votive candles"]
    history: The Purge(major,27y,occupation_infiltration); The Iron Dispute(major,18y,economic)
    PAGE: [Summary/Plot Hooks] No food can be bought in from outside now, so the grain already here is all there is, and its price climbs every week. The settlement must decide how to share it, and those who hold it are watching it decide.

### r2r-thorp-54
    tier thorp pop 17 · crisis famine · prosperity Struggling · route isolated · terrain hills
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: The Religious Conflict(minor,116y,religious); The Crash(minor,61y,economic); The Purge(major,27y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] No food can be bought in from outside now, so the food already here is all there is, and its price climbs every week. The settlement must decide how to share it, and those who hold it are watching it decide.

### r2s-wartime-thorp-3
    tier thorp pop 6 · crisis wartime · prosperity Struggling · route isolated · terrain mountain
    powers 1: Headman's Authority[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: The Siege(catastrophic,94y,disaster); The Migration(minor,45y,demographic); The Purge(major,17y,occupation_infiltration)
    PAGE: [Summary/Plot Hooks] No food can be bought in from outside now, so the food already here is all there is, and its price climbs every week. The settlement must decide how to share it, and those who hold it are watching it decide.

### rr3-metropolis-under_siege-rand-3
    tier metropolis pop 169996 · crisis under_siege · prosperity Struggling · route road · terrain desert
    powers 8: City-State Council[government 31]; War Council[military 18]; Military/Guard[military 14]; Arcane Orders[magic 11]; Religious Authorities[religious 11]; Noble Houses[noble 6]; Merchant Guilds[economy 6]; The Guild Alliance[economy 3] · govt 
    houses (96) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild; Elder Grove Council
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Dressed stone (local quarry depleted)","Bulk grain (local fields depleted)","Livestock","Iron (weapons)","Medicinal herbs","Paper","Paper materials","Salt","Clay and raw materials","Glass sand (local deposits exhausted)"]
    history: The Schism(minor,778y,political); The Great Fire(catastrophic,574y,disaster); The Siege(catastrophic,492y,disaster); The Purge(major,451y,occupation_infiltration); The Migration(major,413y,demographic); The Wild Magic(major,340y,magical); The Arcane Incident(minor,272y,magical); The Succession Crisis(major,191y,political); The Plague Years(catastrophic,165y,disaster); The Heresy Trials(minor,88y,religious); The Economic Divide(minor,22y,economic)
    PAGE: [Summary/Plot Hooks] No food can be bought in from outside now, so the grain already here is all there is, and its price climbs every week. The settlement must decide how to share it, and those who hold it are watching it decide.

## A26 · src/generators/economy/foodBalance.js · import-dependence plot hook (new, famine) · famine; imports cover some and a channel is named · prints in 55 towns (hamlet,village,city,thorp,town,metropolis)

### rr3-city-under_siege+famine-rand-1
    tier city pop 4869 · crisis under_siege+famine · prosperity Struggling · route port · terrain coastal
    powers 5: Religious Authorities[religious 41]; Merchant Guild Council[economy 17]; Military/Guard[military 17]; War Council[military 16]; The Shield Compact[military 9] · govt 
    houses (55) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Sawmill (commercial); Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Guild consortium; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Teleportation circle; Multiple adventurers' guilds; Black market; Gambling halls; Multiple monasteries
    food: sources ["fish"] failed fish granary true · balance {"imp":2705} · exports ["Salted fish (naval route only)","Smoked seafood (naval route only)","Fish oil (naval route only)","Legal services (contracts, notarial)","Military contract services","Cultural tourism revenue","Maritime services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Paper materials","Iron","Grain","Salt (local salt beds exhausted)","Luxury textiles and exotic goods","Advanced weapons and armour (bulk contract)","Incense, ritual oil, and vestment materials","Cordage, canvas, and vessel-maintenance supplies","Incense and ritual oil","Parchment and wax tablets"]
    history: The Wild Magic(minor,197y,magical); The Purge(major,153y,occupation_infiltration); The Arcane Incident(minor,108y,magical); The Siege(major,89y,disaster); The Economic Divide(minor,55y,economic); The Succession Crisis(minor,21y,political)
    PAGE: [Summary/Plot Hooks] The fishing failed here this year, and what food can still be bought from outside costs more every week. The settlement must decide what it can still afford to import, and the merchants are watching it decide.

### r2r-hamlet-16
    tier hamlet pop 20 · crisis famine · prosperity Struggling · route crossroads · terrain riverside
    powers 1: Elder Council[government 100] · govt 
    houses (11) key: Access to external mill; Access to parish church; Palisade or earthworks; Citizen militia
    food: sources ["fish"] failed fish granary false · balance {"imp":15} · exports ["River fish","Freshwater catch","Medicinal herbs","Wild honey","Transit trade","Toll revenue","Salted fish","Smoked seafood"] imports ["Grain","Salt","Cut stone and masonry","Replacement arms and basic equipment","Incense and votive candles"]
    history: The Wild Magic(minor,76y,magical); The Occupation(major,68y,exile_return); The Great Construction(major,48y,economic); The Economic Divide(minor,46y,economic); The Siege(catastrophic,21y,disaster)
    PAGE: [Summary/Plot Hooks] The fishing failed here this year, and what food can still be bought from outside costs more every week. The settlement must decide what it can still afford to import, and the merchants are watching it decide.

### rr3-thorp-famine-port-0
    tier thorp pop 11 · crisis famine · prosperity Struggling · route port · terrain coastal
    powers 1: Elder Council[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":10} · exports [] imports ["Grain","Salt"]
    history: The Purge(major,145y,occupation_infiltration); The Arcane Incident(catastrophic,131y,magical); The Migration(major,106y,demographic); The Succession Crisis(major,7y,political)
    PAGE: [Summary/Plot Hooks] The crops failed here this year, and what food can still be bought from outside costs more every week. The settlement must decide what it can still afford to import, and the merchants are watching it decide.

### rr3-metropolis-famine-rand-5
    tier metropolis pop 124125 · crisis famine · prosperity Struggling · route isolated · terrain mountain
    powers 6: Democratic assembly[government 23]; Military/Guard[military 22]; Thieves' Guild[criminal 18]; Grain Holders[economy 16]; Arcane Orders[magic 13]; The Guild Alliance[economy 8] · govt 
    houses (75) key: District markets (5-10); Multiple market squares; State granary complex; Mills (2-5); Sawmill (commercial); Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Assassins' guild; Airship docking (high magic); Merchant guilds (50-100+); Tailor's guild; Multiple adventurers' guilds; Docks/port facilities; Harbour master's office
    food: sources [] failed null granary true · balance {"imp":95275} · exports ["Mineral salts","Alum","Sulfur","Healing waters (bottled)","Pilgrim hospitality","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","News and information","Maps and charts","Glassware","Legal services (contracts, notarial)","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Wool","Iron","Grain","Paper","Paper materials","Salt","Clay and raw materials","Luxury textiles and exotic goods","Bulk raw materials and agricultural goods","Wool, dairy, and livestock (local alpine pasture depleted)"]
    history: The Plague Years(catastrophic,319y,disaster); The Pilgrimage(major,252y,religious); The Arcane Incident(minor,234y,magical); The Flood(major,218y,disaster); The Land Dispute(minor,208y,political); The Siege(catastrophic,182y,disaster); The Uprising(major,166y,political); The Purge(major,89y,occupation_infiltration); The Migration(minor,26y,demographic); The Occupation(catastrophic,17y,political)
    PAGE: [Summary/Plot Hooks] The crops failed here this year, and what food can still be bought from outside costs more every week. The settlement must decide what it can still afford to import, and the merchants are watching it decide.

## A27 · src/generators/narrativeText.js · PRESSURE_SENTENCES.famine row 0 (gated) · famine; needs institution: granary (new) · prints in 9 towns (town,city,metropolis)

### r2s-famine-town-3
    tier town pop 737 · crisis famine · prosperity Struggling · route road · terrain hills
    powers 3: Arcane Council[magic 35]; Thieves' Guild[criminal 33]; Religious Authorities[religious 32] · govt 
    houses (29) key: Fish market; Weekly market; Market square; Carriers' guild; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Town walls; Gates (if walled); Town watch
    food: sources [] failed null granary true · balance {"imp":567} · exports ["Coal","Medicinal herbs","Alchemical reagents","Wild honey","Herbal remedies","Potions and elixirs","Candles and wax","Alchemical trade (potions, reagents)"] imports ["Bulk grain (local fields depleted)","Iron","Salt","Warehousing and logistics services","Livestock and dairy (local pastures depleted)","Ritual wood and herbs (ancient grove damaged)","Reeds, peat, and marsh herbs (local wetlands exhausted)","Replacement arms and basic equipment","Incense and votive candles","Exotic minerals and salts"]
    history: The Siege(major,98y,disaster); The Succession Crisis(major,65y,political); The Occupation(major,58y,exile_return); The Economic Divide(major,6y,economic)
    PAGE: [Summary/Overview] Shattkarez is two bad weeks from genuine starvation; the remaining grain reserves are in few hands, and whoever holds them is not discussing it openly.

### rr3-town-famine-rand-4
    tier town pop 309 · crisis famine · prosperity Struggling · route road · terrain hills
    powers 2: Church Council[religious 76]; Grain Holders[economy 24] · govt 
    houses (17) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town hall; Town watch; Adventurers' charter hall; Town walls; Bowyers & fletchers (guild)
    food: sources [] failed null granary true · balance {"imp":241} · exports ["Medicinal herbs","Wild honey","Sacred wood","Ritual components","Reeds and thatch","Peat fuel","Waterfowl"] imports ["Iron","Grain","Salt","Cut stone and masonry","Precious metals (local veins exhausted)","Game and hides (local hunting grounds exhausted)","Quality weapons and armour","Incense, ritual oil, and vestment materials","Incense and ritual paper","Fine lacquerwork for shrines"]
    history: The Arcane Incident(major,233y,magical); The Pilgrimage(major,216y,religious); The Migration(major,176y,demographic); The Purge(major,153y,occupation_infiltration); The Siege(catastrophic,121y,disaster); The Occupation(catastrophic,90y,exile_return); The Tyranny(major,36y,political); The Heresy Trials(major,17y,religious)
    PAGE: [Summary/Overview] Beitian is two bad weeks from genuine starvation; the remaining grain reserves are in few hands, and whoever holds them is not discussing it openly.

### rr3-metropolis-famine-rand-4
    tier metropolis pop 83078 · crisis famine · prosperity Struggling · route road · terrain hills
    powers 9: Military/Guard[military 24]; Grand Military Council[military 15]; Noble Houses[noble 14]; Grain Holders[economy 10]; Thieves' Guild[criminal 10]; Arcane Orders[magic 7]; Merchant Guilds[economy 6]; Religious Authorities[religious 6]; The Highborn Circle[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":83223} · exports ["Milled flour","Toll revenue","Pass transit trade","Spellcasting (minor)","Magical identification","News and information","Maps and charts","Glassware","Books and manuscripts","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Iron","Livestock","Dressed stone (local quarry depleted)","Medicinal herbs","Paper","Paper materials","Salt","Grain","Clay and raw materials","Luxury textiles and exotic goods"]
    history: The Heresy Trials(major,245y,religious); The Shortage(minor,235y,economic); The Succession Crisis(minor,168y,political); The Arcane Incident(major,137y,magical); The Migration(major,92y,demographic); The Occupation(major,63y,exile_return); The Siege(catastrophic,31y,disaster); The Purge(major,13y,occupation_infiltration)
    PAGE: [Summary/Overview] Jayahalli is two bad weeks from genuine starvation; the remaining grain reserves are in few hands, and whoever holds them is not discussing it openly.

### r2s-famine-city-0
    tier city pop 2909 · crisis famine · prosperity Struggling · route river · terrain riverside
    powers 5: Noble Families[noble 27]; Royal Authority[government 24]; Military/Guard[military 23]; The Shield Compact[military 12]; The Landed Bloc[noble 14] · govt 
    houses (37) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Sawmill (commercial); Cobbler's guild; Craft guilds (30-80); Parish churches (10-30); City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Barge and river transport company
    food: sources ["fish","mill"] failed fish granary true · balance {"imp":2366} · exports ["River fish","Freshwater catch","Sacred wood","Ritual components","Milled timber","Milled flour","Salted fish","Smoked seafood","Legal services (contracts, notarial)","Military contract services","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Bulk grain (local fields depleted)","Capital","Salt","Iron ore","Charcoal and fuel","Preserved provisions","Route maps and intelligence","Luxury textiles and exotic goods","Reeds, peat, and marsh herbs (local wetlands exhausted)","Incense and votive candles"]
    history: The Land Dispute(minor,203y,political); The Guild War(major,182y,economic); The Purge(major,152y,occupation_infiltration); The Arcane Incident(minor,128y,magical); The Occupation(major,126y,exile_return); The Shortage(major,88y,economic); The Debt Crisis(major,63y,economic); The Siege(major,47y,disaster); The Succession Crisis(minor,27y,political); The Migration(major,9y,demographic)
    PAGE: [Summary/Overview] Weizhen is two bad weeks from genuine starvation; the remaining grain reserves are in few hands, and whoever holds them is not discussing it openly.

## A28 · src/generators/narrativeText.js · PRESSURE_SENTENCES.famine row 4 (gated) · famine; needs institution: granary (new) · prints in 5 towns (town,metropolis,city)

### r2s-famine-town-2
    tier town pop 407 · crisis famine · prosperity Struggling · route port · terrain coastal
    powers 3: Town Mayor[other 39]; Thieves' Guild[criminal 34]; Grain Holders[economy 27] · govt 
    houses (19) key: Weekly market; Market square; Docks/port facilities; Harbour master's office; Town granary; Mills (2-5); Bowyers & fletchers (guild); Craft guilds (5-15); Parish churches (2-5); Town hall; Town watch
    food: sources [] failed null granary true · balance {"imp":413} · exports ["River craft","Cargo barges","Preserved foods","Ocean-going vessels","River barges","Waterborne freight services (cargo, pilotage)"] imports ["Iron","Grain","Salt","Salted fish (local fishing grounds exhausted)","Recovered artefacts (local ruins exhausted)","Replacement arms and basic equipment","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Stolen horses","Felt and leather goods"]
    history: The Migration(minor,39y,demographic)
    PAGE: [Summary/Overview] Town Mayor of Vatanserai promised a fair share of the grain reserves last week, and little of it has reached the poor.

### r2s-famine-metropolis-3
    tier metropolis pop 32388 · crisis famine · prosperity Struggling · route river · terrain riverside
    powers 6: Religious Authorities[religious 32]; Royal Authority[government 21]; Grain Holders[economy 15]; Thieves' Guild[criminal 15]; Noble Houses[noble 11]; The Highborn Circle[noble 6] · govt 
    houses (82) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; State granary complex; Mills (2-5); Sawmill (commercial); Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Harbour master's office; Tailor's guild
    food: sources ["fish","mill"] failed fish granary true · balance {"imp":31301} · exports ["Milled flour","Fulled cloth","Roof tiles","Luxury manufactured goods","Fine metalwork and jewelry","Glassware","Books and manuscripts","Rare spices and exotic dyes","Fine textiles","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Iron ore (local mines exhausted)","Timber (local forests cleared)","Livestock","Dressed stone (local quarry depleted)","Medicinal herbs","Paper materials","Luxury materials","Capital","Grain","Ritual wood and herbs (ancient grove damaged)"]
    history: The Succession Crisis(minor,608y,political); The Religious Conflict(minor,541y,religious); The Plague Years(major,513y,disaster); The Debt Crisis(major,447y,economic); The Flood(catastrophic,427y,disaster); The Great Fire(major,389y,disaster); The Migration(minor,337y,demographic); The Purge(major,305y,occupation_infiltration); The Arcane Incident(minor,276y,magical); The Heresy Trials(minor,200y,religious); The Occupation(major,186y,exile_return); The Uprising(major,125y,political); The Economic Divide(major,88y,economic); The Siege(catastrophic,5y,disaster)
    PAGE: [Summary/Overview] Royal Authority of Nektarambelos promised a fair share of the grain reserves last week, and little of it has reached the poor.

### rr3-city-famine-rand-0
    tier city pop 4925 · crisis famine · prosperity Struggling · route road · terrain mountain
    powers 5: Thieves' Guild[criminal 27]; Corrupt City Council[criminal 23]; Military/Guard[military 19]; Grain Holders[economy 16]; The Shadow Compact[criminal 15] · govt 
    houses (59) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Multiple adventurers' guilds; Whisper market; Black market
    food: sources [] failed null granary true · balance {"imp":4560} · exports ["Pine planks","Charcoal","Toll revenue","Pass transit trade","Transit trade","Barrels and containers","Guild-manufactured goods","News and information","Maps and charts","Financial services (letters of credit)","Legal services (contracts, notarial)","Military contract services","Alchemical trade (potions, reagents)"] imports ["Iron","Wool","Timber","Grain","Salt","Cut stone and masonry","Raw hides and animal products","Luxury textiles and exotic goods","Wool, dairy, and livestock (local alpine pasture depleted)","Precious metals (local veins exhausted)"]
    history: The Economic Divide(minor,135y,economic); The Purge(major,105y,occupation_infiltration); The Succession Crisis(minor,83y,political); The Migration(major,67y,demographic); The Wild Magic(major,58y,magical); The Occupation(major,29y,exile_return); The Siege(major,5y,disaster)
    PAGE: [Summary/Overview] Corrupt City Council of Portaminus promised a fair share of the grain reserves last week, and little of it has reached the poor.

### rr3-city-famine-rand-5
    tier city pop 11520 · crisis famine · prosperity Struggling · route port · terrain coastal
    powers 8: Military City Council[military 17]; Military/Guard[military 15]; Thieves' Guild[criminal 15]; Arcane Orders[magic 13]; Religious Authorities[religious 13]; Grain Holders[economy 11]; Merchant Guilds[economy 8]; The Black Circle[criminal 8] · govt 
    houses (79) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Mages' guild; Teleportation circle; Multiple adventurers' guilds; Thieves' guild chapter; Whisper market; Black market; Gambling halls
    food: sources ["fish"] failed fish granary true · balance {"imp":13525} · exports ["Ship passage","Maritime trade access","Arcane reagents","Potions and elixirs","Barrels and containers","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Maritime services (cargo, pilotage)","Alchemical trade (potions, reagents)"] imports ["Herbs","Precious metals","Iron","Grain","Timber","Luxury materials","Salt","Luxury textiles and exotic goods","Salted fish (local fishing grounds exhausted)","Replacement arms and basic equipment"]
    history: The Siege(catastrophic,460y,disaster); The Schism(minor,424y,political); The Migration(minor,370y,demographic); The Succession Crisis(minor,356y,political); The Arcane Incident(major,281y,magical); The Occupation(major,264y,exile_return); The Purge(major,227y,occupation_infiltration); The Economic Divide(minor,197y,economic); The Pilgrimage(minor,124y,religious); The Wild Magic(minor,14y,magical)
    PAGE: [Summary/Overview] Military City Council of Frosthavn promised a fair share of the grain reserves last week, and little of it has reached the poor.

## A29 · src/generators/narrativeText.js · famineFoodIsPower (≥3 powers) · famine; powerCount ≥ 3 · prints in 7 towns (village,town,metropolis)

### r2s-famine-village-3
    tier village pop 257 · crisis famine · prosperity Struggling · route isolated · terrain hills
    powers 3: Military/Guard[military 40]; Religious Authorities[religious 35]; Elder Council[government 25] · govt 
    houses (16) key: Mill; Parish church; Priest (resident); Palisade or earthworks; Citizen militia
    food: sources [] failed null granary false · balance {"imp":25} · exports [] imports ["Replacement arms and basic equipment","Incense and votive candles"]
    history: The Uprising(major,49y,political); The Migration(minor,10y,demographic)
    PAGE: [Summary/Overview] Since the harvest failed, whoever holds the food in Jabalkhel holds the power, and at least three powers are fighting over what food is left.

### rr3-metropolis-famine-rand-3
    tier metropolis pop 72345 · crisis famine · prosperity Struggling · route isolated · terrain desert
    powers 9: Royal Authority[government 18]; Religious Authorities[religious 15]; Noble Houses[noble 13]; Thieves' Guild[criminal 13]; Military/Guard[military 11]; Arcane Orders[magic 9]; Grain Holders[economy 9]; The Enlightened[magic 5]; The Peerage[noble 7] · govt 
    houses (99) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild; Airship docking (high magic); Docks/port facilities; Harbour master's office
    food: sources [] failed null granary true · balance {"imp":55889} · exports ["Reeds and thatch","Waterfowl","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","Furs and pelts","Game meat","Hunting trophies","Spellcasting (minor)","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Stone","Grain","Medicinal herbs","Paper","Paper materials","Salt (local desert pans exhausted)","Raw hides and animal products","Charcoal and fuel","Warehousing and logistics services","Preserved provisions"]
    history: The Occupation(major,499y,exile_return); The Religious Conflict(major,455y,religious); The Uprising(catastrophic,374y,political); The Great Fire(catastrophic,326y,disaster); The Economic Divide(minor,289y,economic); The Land Dispute(major,192y,political); The Wild Magic(major,163y,magical); The Migration(major,93y,demographic); The Succession Crisis(minor,18y,political)
    PAGE: [Summary/Overview] Since the harvest failed, whoever holds the food in Ribatkarez holds the power, and at least three powers are fighting over the stores.

### r2s-famine-town-1
    tier town pop 1336 · crisis famine · prosperity Struggling · route crossroads · terrain hills
    powers 4: Religious Authorities[religious 36]; Merchant oligarchy[economy 26]; Merchant Guilds[economy 21]; Military/Guard[military 17] · govt 
    houses (35) key: Fish market; Weekly market; Market square; Merchant guilds (3-8); Town granary; Mills (2-5); Tailor's guild; Craft guilds (5-15); Parish churches (2-5); Town hall; Courthouse; Town watch; Free company hall; Adventurers' charter hall; Town walls; Bowyers & fletchers (guild); Elder Grove Council
    food: sources [] failed null granary true · balance {"imp":1226} · exports ["Milled flour","Transit trade","Toll revenue","Rare spices and exotic dyes","Furs and pelts","Meals and drink","Preserved foods","Caravan trade goods","Exotic imports","Cargo handling (transit)","Toll income (transit)","Legal services (contracts, notarial)"] imports ["Iron ore (local mines exhausted)","Salt","Grain","Advanced weapons and armour (bulk contract)","Incense, ritual oil, and vestment materials","Incense and ritual paper","Quality paper and ink"]
    history: The Succession Crisis(major,93y,political); The Great Harvest Compact(minor,85y,economic); The Arcane Incident(minor,59y,magical)
    PAGE: [Summary/Overview] Since the harvest failed, whoever holds the food in Hongcheng holds the power, and at least three powers are fighting over the stores.

### r2s-famine-metropolis-1
    tier metropolis pop 35674 · crisis famine · prosperity Struggling · route road · terrain riverside
    powers 7: Noble Houses[noble 25]; Military/Guard[military 23]; Ducal Governorship[government 16]; Merchant Guilds[economy 14]; Arcane Orders[magic 10]; The Mages' Compact[magic 5]; The Trade Compact[economy 7] · govt 
    houses (93) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful)
    food: sources ["fish"] failed fish granary true · balance {"imp":28175} · exports ["River fish","Freshwater catch","Transit trade","Toll revenue","Pass transit trade","Salted fish","Smoked seafood","Spellcasting (minor)","Magical identification","News and information","Maps and charts","Glassware","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Wool","Iron ore (local mines exhausted)","Grain","Medicinal herbs","Paper","Paper materials","Salt","Clay and raw materials","Livestock and dairy (local pastures depleted)","Reeds, peat, and marsh herbs (local wetlands exhausted)"]
    history: The Interregnum(major,444y,political); The Land Dispute(major,398y,political); The Wild Magic(major,367y,magical); The Succession Crisis(major,334y,political); The Schism(minor,312y,political); The Great Fire(major,261y,disaster); The Plague Years(major,233y,disaster); The Flood(catastrophic,212y,disaster); The Shortage(minor,199y,economic); The Crash(minor,150y,economic); The Purge(major,129y,political); The Occupation(major,106y,exile_return); The Arcane Incident(minor,90y,magical); The Economic Divide(minor,68y,economic); The Siege(catastrophic,27y,disaster); The Migration(major,10y,demographic)
    PAGE: [Summary/Overview] Since the fishing failed, whoever holds the food in Hongji holds the power, and at least three powers are fighting over the stores.

## A30 · src/generators/narrativeText.js · famineFoodIsPower (2 powers) · famine; powerCount = 2 · prints in 6 towns (village,hamlet)

### r2r-village-24
    tier village pop 275 · crisis famine · prosperity Struggling · route road · terrain forest
    powers 2: Elder Council[government 57]; Grain Holders[economy 43] · govt 
    houses (16) key: Mill; Parish church; Priest (resident); Adventurers' charter hall
    food: sources [] failed null granary false · balance {"imp":134} · exports ["Toll revenue","Pass transit trade"] imports ["Salt","Grain","Route maps and intelligence","Replacement arms and basic equipment","Incense and votive candles","Fine porcelain and lacquerware"]
    history: The Siege(major,18y,disaster)
    PAGE: [Summary/Overview] Since the harvest failed, whoever holds the food in Shandao holds the power, and its two powers are fighting over what food is left.

### rr3-hamlet-famine-rand-4
    tier hamlet pop 54 · crisis famine · prosperity Struggling · route port · terrain coastal
    powers 2: Feudal Stewardship[government 58]; Grain Holders[economy 42] · govt 
    houses (12) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed fish granary false · balance {"imp":46} · exports ["Shipbuilding timber","Barrels and containers"] imports ["Grain","Salt","Incense and votive candles"]
    history: The Arcane Incident(major,85y,magical); The Economic Divide(minor,57y,economic)
    PAGE: [Summary/Overview] Since the fishing failed, whoever holds the food in Lagosaltus holds the power, and its two powers are fighting over what food is left.

### rr3-village-famine-rand-1
    tier village pop 372 · crisis famine · prosperity Struggling · route isolated · terrain mountain
    powers 2: Religious Authorities[religious 62]; Elder Council[government 38] · govt 
    houses (14) key: Mill; Sawmill; Parish church; Priest (resident); Adventurers' charter hall
    food: sources [] failed null granary false · balance {"imp":38} · exports [] imports ["Incense and votive candles"]
    history: The Occupation(major,203y,exile_return); The Iron Dispute(major,179y,economic); The Economic Divide(minor,164y,economic); The Migration(minor,140y,demographic); The Siege(catastrophic,69y,disaster); The Heresy Trials(major,30y,religious)
    PAGE: [Summary/Overview] Since the harvest failed, whoever holds the food in Puripuram holds the power, and its two powers are fighting over what food is left.

### r2s-famine-village-1
    tier village pop 90 · crisis famine · prosperity Struggling · route river · terrain riverside
    powers 2: Military/Guard[military 64]; Headman's Authority[government 36] · govt 
    houses (12) key: Mill; Parish church; Priest (resident); Palisade or earthworks; Citizen militia
    food: sources ["fish"] failed fish granary false · balance {"imp":57} · exports ["River fish","Freshwater catch","Reeds and thatch","Peat fuel","Waterfowl","Salted fish","Smoked seafood"] imports ["Grain","Salt","Replacement arms and basic equipment","Incense and votive candles","Rope, oakum, and rigging supplies","Lacquered armour fittings"]
    history: The Migration(minor,146y,demographic); The Shortage(major,122y,economic); The Iron Dispute(major,89y,economic); The Succession Crisis(minor,88y,political); The Siege(catastrophic,48y,disaster); The Pilgrimage(major,36y,religious)
    PAGE: [Summary/Overview] Since the fishing failed, whoever holds the food in Humen holds the power, and its two powers are fighting over what food is left.

## A31 · src/generators/narrativeText.js · famineFoodIsPower (≤1 power) · famine; powerCount ≤ 1 · prints in 26 towns (thorp,hamlet,village)

### r2r-thorp-17
    tier thorp pop 11 · crisis famine · prosperity Struggling · route isolated · terrain hills
    powers 1: Household Council[government 100] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["game"] failed game granary false · balance {"imp":0} · exports [] imports []
    history: The Migration(minor,142y,demographic); The Great Construction(major,125y,economic); The Occupation(catastrophic,101y,exile_return); The Purge(major,21y,occupation_infiltration)
    PAGE: [Summary/Overview] Since the hunt failed, food is power in Chichich, and everyone is watching who eats well.

### r2s-succession_void-thorp-0
    tier thorp pop 8 · crisis succession_void+famine · prosperity Struggling · route isolated · terrain hills
    powers 1: Household Council[government 100] · govt 
    houses (9) key: Access to external mill; Access to parish church; Palisade
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: The Economic Divide(minor,170y,economic); The Purge(major,107y,occupation_infiltration); The Succession Crisis(minor,19y,political)
    PAGE: [Summary/Overview] Since the harvest failed, food is power in Qingmen, and everyone is watching who eats well.

### rr3-village-famine-rand-3
    tier village pop 193 · crisis famine · prosperity Struggling · route river · terrain riverside
    powers 1: Priestly Guidance[religious 100] · govt 
    houses (15) key: Mill; Parish church; Priest (resident)
    food: sources ["livestock","fish","mill"] failed livestock granary false · balance {"imp":43} · exports ["Milled flour","Raw wool","Livestock","Leather goods","Healing waters (bottled)","Pilgrim hospitality","Flour and meal","Preserved foods"] imports ["Grain","Salt","Incense and votive candles","Cordage, canvas, and vessel-maintenance supplies","Incense and ritual oil"]
    history: The Arcane Incident(major,184y,magical); The Purge(major,124y,occupation_infiltration); The Flood(major,112y,disaster); The Economic Divide(minor,52y,economic); The Religious Conflict(major,31y,religious)
    PAGE: [Summary/Overview] Since the herds failed, food is power in Lidofundus, and everyone is watching who eats well.

### r2r-thorp-38
    tier thorp pop 26 · crisis famine · prosperity Struggling · route isolated · terrain mountain
    powers 1: Household Council[government 100] · govt 
    houses (9) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: 
    PAGE: [Summary/Overview] Since the harvest failed, food is power in Khanabad, and everyone is watching who eats well.

## A32 · src/generators/narrativeText.js · PRESSURE_SENTENCES.wartime levies (default now the food word) · wartime, not economy-output branch · prints in 29 towns (thorp,hamlet,town,village,city,metropolis)

### r2r-thorp-32
    tier thorp pop 8 · crisis wartime · prosperity Struggling · route road · terrain mountain
    powers 1: Household Council[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":2} · exports ["Mineral salts","Alum","Sulfur","Raw wool","Livestock","Toll revenue","Pass transit trade"] imports ["Salt"]
    history: The Religious Conflict(minor,157y,religious); The Great Construction(major,137y,economic); The Siege(major,98y,disaster); The Purge(major,56y,occupation_infiltration)
    PAGE: [Summary/Overview] The war reaches Hochsee as a series of demands rather than battles: levies of men, of salt, of coin, each one framed as duty and none of them refusable. Hochsee is losing people and resources it will not get back, and the front it is bleeding for is somewhere it will never see.

### r2s-wartime-metropolis-2
    tier metropolis pop 160267 · crisis wartime · prosperity Poor · route road · terrain hills
    powers 10: Ducal Governorship[government 23]; War Council[military 15]; Thieves' Guild[criminal 14]; Merchant Guilds[economy 11]; Noble Houses[noble 8]; Military/Guard[military 8]; Religious Authorities[religious 8]; Arcane Orders[magic 6]; The Tower Alliance[magic 3]; The Old Houses[noble 4] · govt 
    houses (94) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources [] failed null granary true · balance {"imp":160970} · exports ["Spellcasting (minor)","Magical identification","News and information","Maps and charts","Glassware","Books and manuscripts","Financial services (letters of credit)","Legal services (contracts, notarial)","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Bulk grain (local fields depleted)","Livestock","Iron","Medicinal herbs","Paper","Paper materials","Salt","Clay and raw materials","Herbs and forage (local gathering areas exhausted)","Ritual wood and herbs (ancient grove damaged)"]
    history: The Trade Collapse(major,194y,economic); The Interregnum(catastrophic,178y,political); The Schism(minor,147y,political); The Flood(catastrophic,138y,disaster); The Arcane Incident(major,118y,magical); The Purge(major,95y,occupation_infiltration); The Migration(major,78y,demographic); The Economic Divide(major,41y,economic); The Uprising(catastrophic,36y,political); The Occupation(catastrophic,8y,exile_return)
    PAGE: [Summary/Overview] The war reaches Nanwan as a series of demands rather than battles: levies of men, of grain, of coin, each one framed as duty and none of them refusable. Nanwan is losing people and resources it will not get back, and the front it is bleeding for is somewhere it will never see.

### r2r-thorp-56
    tier thorp pop 24 · crisis wartime · prosperity Poor · route river · terrain riverside
    powers 1: Household Council[government 100] · govt 
    houses (9) key: Access to external mill; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["River fish","Freshwater catch","Grain surplus","Sacred wood","Ritual components"] imports []
    history: The Siege(major,200y,disaster); The Great Harvest Compact(major,149y,economic); The Succession Crisis(major,134y,political); The Pilgrimage(major,24y,religious)
    PAGE: [Summary/Overview] The war reaches Kitaguan as a series of demands rather than battles: levies of men, of fish, of coin, each one framed as duty and none of them refusable. Kitaguan is losing people and resources it will not get back, and the front it is bleeding for is somewhere it will never see.

### r2r-hamlet-5
    tier hamlet pop 97 · crisis wartime · prosperity Poor · route road · terrain riverside
    powers 2: Elder Council[government 51]; War Council[military 49] · govt 
    houses (11) key: Access to external mill; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["River fish","Freshwater catch","Grain surplus","Sacred wood","Ritual components","Salted fish","Smoked seafood","Ale (barrel)","Beer (barrel)","Quality tools and weapons","Advanced weapons and armor"] imports ["Incense and votive candles"]
    history: The Interregnum(catastrophic,101y,political); The Arcane Incident(major,59y,magical); The Occupation(catastrophic,51y,exile_return); The Great Harvest Compact(minor,46y,economic); The Purge(major,14y,occupation_infiltration)
    PAGE: [Summary/Overview] The war reaches Achilpolis as a series of demands rather than battles: levies of men, of fish, of coin, each one framed as duty and none of them refusable. Achilpolis is losing people and resources it will not get back, and the front it is bleeding for is somewhere it will never see.

## A33 · src/generators/narrativeGenerator.js (commodity scan, no first word) · the 6 other pressure rows reading r.commodity, now their own defaults where the scan names none · indebted / succession_void / under_siege(mill) / mass_migration / wartime(forges) / slave_revolt · prints in 74 towns (village,city,metropolis,thorp,hamlet,town)

### rr3-thorp-slave_revolt-rand-5
    tier thorp pop 5 · crisis slave_revolt · prosperity Struggling · route road · terrain mountain
    powers 1: Household Council[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":1} · exports ["Mineral salts","Alum","Sulfur","Raw wool","Livestock","Transit trade","Toll revenue"] imports ["Salt"]
    history: The Occupation(major,141y,exile_return); The Succession Crisis(minor,74y,political)
    PAGE: [Summary/Overview] In Fortecastra the two sides have discovered they cannot simply win: the enslaved cannot hold the whole settlement, and Household Council cannot retake it without destroying the salt that made it worth holding. What comes next will be a bargain neither wanted, struck between people who no longer pretend to be anything but enemies.

### r2s-succession_void-metropolis-3
    tier metropolis pop 295750 · crisis succession_void · prosperity Wealthy · route road · terrain mountain
    powers 10: Merchant Guilds[economy 17]; Grand Merchant Senate[economy 16]; Religious Authorities[religious 14]; Craft Guilds[economy 10]; Arcane Orders[magic 10]; Military/Guard[military 9]; The Highborn Circle[noble 8]; The Peerage[noble 7]; Noble Houses[noble 6]; The Landed Bloc[noble 3] · govt 
    houses (95) key: Fish market; District markets (5-10); Multiple market squares; State granary complex; Mills (2-5); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; Mayor and council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild; Merchant guilds (50-100+)
    food: sources [] failed null granary true · balance {"imp":317058} · exports ["Coal","Reeds and thatch","Waterfowl","Spellcasting (minor)","Magical identification","News and information","Maps and charts","Glassware","Books and manuscripts","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Timber (local forests cleared)","Wool","Stone","Iron","Grain","Medicinal herbs","Paper","Paper materials","Salt","Preserved provisions"]
    history: The Tyranny(major,742y,political); The Pilgrimage(major,696y,religious); The Crash(major,627y,economic); The Trade Collapse(major,609y,economic); The Land Dispute(minor,563y,political); The Debt Crisis(major,517y,economic); The Guild War(minor,458y,economic); The Great Fire(catastrophic,408y,disaster); The Heresy Trials(major,352y,religious); The Plague Years(catastrophic,295y,disaster); The Purge(major,255y,political); The Religious Conflict(minor,211y,religious); The Economic Divide(minor,169y,economic); The Migration(minor,146y,demographic); The Occupation(catastrophic,112y,exile_return); The Succession Crisis(minor,69y,political); The Arcane Incident(minor,5y,magical)
    PAGE: [Summary/Overview] The succession in Erdenbalik will be settled by the trade more than by any claim of blood or law: whoever the merchants and the creditors decide to deal with becomes, retroactively, the legitimate successor.

### r2r-village-57
    tier village pop 261 · crisis succession_void · prosperity Prosperous · route road · terrain mountain
    powers 3: Merchant Guilds[economy 48]; Craft Guilds[economy 29]; Elected Reeve[other 23] · govt 
    houses (17) key: Mill; Parish church; Priest (resident); Weekly market
    food: sources [] failed null granary false · balance {"imp":26} · exports ["Mineral salts","Alum","Sulfur","Hardwood beams","Transit trade","Toll revenue","Coal","Barrels and containers"] imports ["Incense and votive candles","Cacao in bulk"]
    history: The Occupation(catastrophic,186y,exile_return); The Great Fire(major,160y,disaster); The Purge(major,109y,occupation_infiltration); The Crash(minor,56y,economic); The Land Dispute(major,10y,political)
    PAGE: [Summary/Overview] The succession in Tlalche will be settled by the salt more than by any claim of blood or law: whoever the merchants and the creditors decide to deal with becomes, retroactively, the legitimate successor.

### r2r-city-10
    tier city pop 8293 · crisis succession_void · prosperity Prosperous · route crossroads · terrain plains
    powers 6: Religious Authorities[religious 24]; Merchant Guild Council[economy 20]; Merchant Guilds[economy 20]; The Highborn Circle[noble 14]; The Peerage[noble 12]; Craft Guilds[economy 10] · govt 
    houses (73) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; Elder Grove Council; Guild consortium; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Multiple adventurers' guilds; Whisper market; Black market
    food: sources [] failed null granary true · balance {"imp":4677} · exports ["Transit trade","Toll revenue","Medicinal herbs","Wild honey","Luxury manufactured goods","Fine metalwork and jewelry","Rare spices and exotic dyes","Glassware","Books and manuscripts","Fine textiles","Herbal remedies","Potions and elixirs","Quality tools and weapons","Financial services (letters of credit)","Legal services (contracts, notarial)","Military contract services"] imports ["Iron","Luxury materials","Precious metals","Grain","Timber","Salt","Luxury textiles and exotic goods","Game and hides (local hunting grounds exhausted)","Gemstones (local deposits exhausted)","Coal and fuel (local seams exhausted)"]
    history: The Arcane Incident(minor,286y,magical); The Migration(major,243y,demographic); The Flood(catastrophic,206y,disaster); The Pilgrimage(major,159y,religious); The Occupation(major,139y,exile_return); The Guild War(minor,103y,economic); The Great Fire(catastrophic,84y,disaster); The Purge(major,57y,occupation_infiltration); The Succession Crisis(minor,9y,political)
    PAGE: [Summary/Overview] The succession in Dharmamandal will be settled by the trade more than by any claim of blood or law: whoever the merchants and the creditors decide to deal with becomes, retroactively, the legitimate successor.

## A34 · src/generators/narrativeText.js · POLITICAL_FLAVOR.economic 'long past' (new) · picked economic event yearsAgo > 60 · prints in 3 towns (city,town,village)

### rr3-village-slave_revolt-rand-3
    tier village pop 122 · crisis slave_revolt · prosperity Struggling · route road · terrain hills
    powers 2: Military Party[military 63]; Household Council[government 37] · govt 
    houses (12) key: Fish market; Mill; Parish church; Priest (resident)
    food: sources [] failed null granary false · balance {"imp":25} · exports ["Reeds and thatch","Peat fuel","Waterfowl","Toll revenue","Pass transit trade"] imports ["Salt","Replacement arms and basic equipment","Incense and votive candles","Incense and ritual paper"]
    history: The Migration(minor,86y,demographic); The Great Construction(major,72y,economic); The Purge(major,68y,occupation_infiltration); The Guild War(minor,23y,economic); The Religious Conflict(minor,11y,religious)
    PAGE: [Summary/Overview] "Economically dynamic in ways that occasionally tip into instability: the Great Construction is long past, but nobody here has forgotten that prosperity has always been earned and can always be lost"
      [World/History] "Economically dynamic in ways that occasionally tip into instability: the Great Construction is long past, but nobody here has forgotten that prosperity has always been earned and can always be lost"

### r2r-city-29
    tier city pop 5866 · crisis none · prosperity Comfortable · route road · terrain hills
    powers 5: Merchant oligarchy[economy 44]; Merchant Guilds[economy 19]; Thieves' Guild[criminal 17]; The Commercial Circle[economy 11]; The Underground[criminal 9] · govt 
    houses (63) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); City granaries; Mills (2-5); Cobbler's guild; Tailor's guild; Craft guilds (30-80); Parish churches (10-30); City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Black market; Multiple monasteries; Hireling hall
    food: sources [] failed null granary true · balance {"imp":3513} · exports ["Reeds and thatch","Waterfowl","Toll revenue","Pass transit trade","Milled flour","Transit trade","Glassware","Books and manuscripts","Toll income (transit)","Legal services (contracts, notarial)","Military contract services","Alchemical trade (potions, reagents)"] imports ["Iron","Livestock","Medicinal herbs","Timber","Salt","Luxury textiles and exotic goods","Coal and fuel (local seams exhausted)","Incense, ritual oil, sacred texts, and vestment cloth (bulk)","Alchemical reagents and scribal supplies","Cotton cloth in bulk"]
    history: The Siege(major,277y,disaster); The Economic Divide(major,171y,economic); The Great Harvest Compact(minor,140y,economic); The Succession Crisis(minor,101y,political); The Migration(major,12y,demographic)
    PAGE: [Summary/Overview] "Economically dynamic in ways that occasionally tip into instability: the Great Harvest Compact is long past, but nobody here has forgotten that prosperity has always been earned and can always be lost"
      [World/History] "Economically dynamic in ways that occasionally tip into instability: the Great Harvest Compact is long past, but nobody here has forgotten that prosperity has always been earned and can always be lost"

### r2s-insurgency-town-2
    tier town pop 2081 · crisis insurgency · prosperity Comfortable · route crossroads · terrain hills
    powers 5: Feudal Appointee[noble 31]; People's Council[government 29]; Merchant Guilds[economy 16]; Religious Authorities[religious 15]; Landed Gentry[noble 9] · govt 
    houses (32) key: Weekly market; Market square; Town granary; Mills (2-5); Tailor's guild; Craft guilds (5-15); Parish churches (2-5); Town hall; Courthouse; Town watch; Town walls; Fish market; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":418} · exports ["Raw wool","Transit trade","Toll revenue","Cavalry mounts","Draft horses","Processed textiles","Guild-manufactured goods","Finished clothing","Dyed cloth","Rare spices and exotic dyes","Quality tools and weapons","Legal services (contracts, notarial)","Alchemical trade (potions, reagents)"] imports ["Bulk grain (local fields depleted)","Iron","Salt","Raw hides and animal products","Incense, ritual oil, and vestment materials","Alchemical reagents and scribal supplies","Gold and silver torcs","Bronze fittings and tools"]
    history: The Debt Crisis(major,245y,economic); The Arcane Incident(major,215y,magical); The Economic Divide(major,166y,economic); The Siege(major,143y,disaster); The Pilgrimage(minor,107y,religious); The Succession Crisis(major,71y,political); The Occupation(major,48y,exile_return); The Purge(major,23y,occupation_infiltration)
    PAGE: [Summary/Overview] "Economically dynamic in ways that occasionally tip into instability: the Economic Divide is long past, but nobody here has forgotten that prosperity has always been earned and can always be lost"
      [World/History] "Economically dynamic in ways that occasionally tip into instability: the Economic Divide is long past, but nobody here has forgotten that prosperity has always been earned and can always be lost"

## A35 · src/generators/narrativeText.js · POLITICAL_FLAVOR.economic 'long past' (new) · picked economic event yearsAgo > 60 · prints in 7 towns (town,metropolis,village)

### rr3-town-occupied-rand-1
    tier town pop 2035 · crisis occupied · prosperity Poor · route crossroads · terrain plains
    powers 3: Merchant Guilds[economy 38]; Merchant oligarchy[economy 36]; Occupation Authority[military 26] · govt 
    houses (43) key: Fish market; Weekly market; Market square; Merchant guilds (3-8); Carriers' guild; Town granary; Mills (2-5); Cobbler's guild; Craft guilds (5-15); Parish churches (2-5); Elder Grove Council; Town hall; Courthouse; Town watch; Tailor's guild
    food: sources [] failed null granary true · balance {"imp":869} · exports ["Raw wool (taxed by occupation)","Livestock (taxed by occupation)","Transit trade (taxed by occupation)","Toll revenue (taxed by occupation)","Quarried stone (taxed by occupation)","Legal services (contracts, notarial)","Alchemical trade (potions, reagents)"] imports ["Bulk grain (local fields depleted)","Salt","Advanced weapons and armour (bulk contract)","Incense and votive candles","Cacao in bulk","Rubber and copal resin"]
    history: The Arcane Incident(major,118y,magical); The Iron Dispute(minor,100y,economic); The Purge(major,90y,occupation_infiltration); The Migration(major,48y,demographic); The Shortage(minor,12y,economic)
    PAGE: [Summary/Overview] "People here are careful not to show off their money. The Iron Dispute is long past, but flaunting wealth still looks like having learned nothing from it"
      [World/History] "People here are careful not to show off their money. The Iron Dispute is long past, but flaunting wealth still looks like having learned nothing from it"

### rr3-village-religious_conversion-rand-1
    tier village pop 242 · crisis religious_conversion · prosperity Poor · route river · terrain forest
    powers 2: Headman's Authority[government 61]; Reform Congregation[religious 39] · govt 
    houses (16) key: Mill; Parish church; Priest (resident)
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Hardwood beams","Healing waters (bottled)","Pilgrim hospitality","Barrels and containers","River craft","Cargo barges"] imports ["Incense and votive candles","Rope, oakum, and rigging supplies","Silver and hack-silver"]
    history: The Guild War(minor,69y,economic); The Purge(major,52y,occupation_infiltration); The Economic Divide(minor,43y,economic); The Religious Conflict(minor,12y,religious)
    PAGE: [Summary/Overview] "People here are careful not to show off their money. The Guild War is long past, but flaunting wealth still looks like having learned nothing from it"
      [World/History] "People here are careful not to show off their money. The Guild War is long past, but flaunting wealth still looks like having learned nothing from it"

### r2r-metropolis-43
    tier metropolis pop 84197 · crisis none · prosperity Prosperous · route road · terrain mountain
    powers 7: Royal Authority[government 40]; Religious Authorities[religious 16]; Merchant Guilds[economy 11]; Noble Houses[noble 10]; Arcane Orders[magic 10]; Craft Guilds[economy 7]; The Guild Alliance[economy 6] · govt 
    houses (94) key: District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Airship docking (high magic); Cartographer's guild; Docks/port facilities
    food: sources [] failed null granary true · balance {"imp":87898} · exports ["Mineral salts","Alum","Sulfur","Charcoal","Toll revenue","Pass transit trade","Bows and crossbows","Arrows (sheaf)","Spellcasting (minor)","Magical identification","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Dressed stone (local quarry depleted)","Wool","Iron","Grain","Clay and raw materials","Luxury textiles and exotic goods","Bulk raw materials and agricultural goods","Timber (mountain stands cleared)","Game and hides (local hunting grounds exhausted)","Gemstones (local deposits exhausted)"]
    history: The Religious Conflict(minor,598y,religious); The Shortage(major,561y,economic); The Pilgrimage(major,500y,religious); The Trade Collapse(major,462y,economic); The Guild War(minor,423y,economic); The Land Dispute(minor,327y,political); The Occupation(major,254y,exile_return); The Arcane Incident(minor,211y,magical); The Purge(major,161y,occupation_infiltration); The Siege(major,150y,disaster); The Migration(minor,102y,demographic); The Economic Divide(minor,65y,economic); The Heresy Trials(major,24y,religious)
    PAGE: [Summary/Overview] "People here are careful not to show off their money. The Guild War is long past, but flaunting wealth still looks like having learned nothing from it"
      [World/History] "People here are careful not to show off their money. The Guild War is long past, but flaunting wealth still looks like having learned nothing from it"

### r2r-town-32
    tier town pop 2057 · crisis none · prosperity Prosperous · route crossroads · terrain hills
    powers 3: Guild Council[economy 50]; Merchant Guilds[economy 31]; Craft Guilds[economy 19] · govt 
    houses (40) key: Fish market; Weekly market; Market square; Merchant guilds (3-8); Carriers' guild; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Guild governance; Town hall; Courthouse; Town walls; Town watch; Adventurers' charter hall
    food: sources [] failed null granary true · balance {"imp":613} · exports ["Raw wool","Livestock","Transit trade","Toll revenue","Milled flour","Cavalry mounts","Draft horses","Processed textiles","Guild-manufactured goods","Rare spices and exotic dyes","Meals and drink","Preserved foods","Financial services (letters of credit)","Legal services (contracts, notarial)"] imports ["Precious metals","Iron","Salt","Warehousing and logistics services","Coal and fuel (local seams exhausted)","Incense, ritual oil, and vestment materials","Iron and steel tools","Sesame oil and ghee"]
    history: The Debt Crisis(major,227y,economic); The Religious Conflict(minor,213y,religious); The Occupation(major,182y,exile_return); The Succession Crisis(major,126y,political); The Siege(major,86y,disaster); The Trade Collapse(major,45y,economic); The Purge(major,32y,occupation_infiltration)
    PAGE: [Summary/Overview] "People here are careful not to show off their money. The Debt Crisis is long past, but flaunting wealth still looks like having learned nothing from it"
      [World/History] "People here are careful not to show off their money. The Debt Crisis is long past, but flaunting wealth still looks like having learned nothing from it"

## A36 · src/generators/narrativeText.js · POLITICAL_FLAVOR.stable row 0 (two majors, new) · ≥ 2 major/catastrophic events · prints in 8 towns (hamlet,village,city,metropolis)

### r2r-hamlet-46
    tier hamlet pop 33 · crisis none · prosperity Moderate · route road · terrain forest
    powers 1: Household Council[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Transit trade","Toll revenue"] imports ["Salt","Incense and votive candles"]
    history: The Debt Crisis(major,95y,economic); The Succession Crisis(minor,68y,political); The Siege(catastrophic,39y,disaster); The Occupation(catastrophic,23y,exile_return)
    PAGE: [Summary/Overview] "It has come through the Debt Crisis and the Siege and simply continued, and that took more work than it looks"
      [World/History] "It has come through the Debt Crisis and the Siege and simply continued, and that took more work than it looks"

### r2r-metropolis-20
    tier metropolis pop 46328 · crisis none · prosperity Prosperous · route river · terrain forest
    powers 7: High Theocratic Council[religious 36]; Religious Authorities[religious 18]; Military/Guard[military 11]; Merchant Guilds[economy 10]; Noble Houses[noble 8]; The Martial Alliance[military 7]; The Holy Compact[religious 10] · govt 
    houses (90) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds
    food: sources ["fish"] failed null granary true · balance {"imp":47790} · exports ["Milled flour","Coal","Healing waters (bottled)","Pilgrim hospitality","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","News and information","Maps and charts","Luxury manufactured goods","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Timber (local forests cleared)","Stone","Livestock and dairy (local pastures depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Luxury textiles and exotic goods","Bulk raw materials and agricultural goods"]
    history: The Heresy Trials(minor,354y,religious); The Wild Magic(minor,335y,magical); The Arcane Incident(minor,220y,magical); The Occupation(catastrophic,199y,exile_return); The Purge(major,170y,occupation_infiltration); The Succession Crisis(minor,145y,political); The Migration(minor,122y,demographic); The Siege(major,83y,disaster); The Religious Conflict(minor,33y,religious); The Economic Divide(major,31y,economic)
    PAGE: [Summary/Overview] "It has come through the Occupation and the Purge and simply continued, and that took more work than it looks"
      [World/History] "It has come through the Occupation and the Purge and simply continued, and that took more work than it looks"

### r2r-hamlet-26
    tier hamlet pop 71 · crisis none · prosperity Poor · route river · terrain coastal
    powers 1: Free Elder Council[government 100] · govt 
    houses (17) key: Access to external mill; Wayside shrine; Access to parish church; Palisade or earthworks; Citizen militia
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports ["Salted fish","Smoked seafood","Fish oil","Grain surplus","Sacred wood","Ritual components","Coal"] imports ["Replacement arms and basic equipment","Incense and votive candles"]
    history: The Debt Crisis(major,65y,economic); The Great Harvest Compact(minor,52y,economic); The Plague Years(catastrophic,35y,disaster); The Religious Conflict(minor,29y,religious)
    PAGE: [Summary/Overview] "It has come through the Debt Crisis and the Plague Years and simply continued, and that took more work than it looks"
      [World/History] "It has come through the Debt Crisis and the Plague Years and simply continued, and that took more work than it looks"

### r2r-village-11
    tier village pop 374 · crisis none · prosperity Prosperous · route port · terrain coastal
    powers 3: Headman's Authority[government 49]; Merchant Guilds[economy 32]; Craft Guilds[economy 19] · govt 
    houses (17) key: Fish market; Mill; Sawmill; Parish church; Priest (resident)
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Milled lumber","Sea salt","Barrels and containers","River craft","Cargo barges","Preserved foods"] imports ["Incense and votive candles","Cordage, canvas, and vessel-maintenance supplies","Silver ornaments and coins"]
    history: The Debt Crisis(major,68y,economic); The Occupation(catastrophic,53y,exile_return); The Economic Divide(minor,34y,economic); The Succession Crisis(minor,10y,political)
    PAGE: [Summary/Overview] "It has come through the Debt Crisis and the Occupation and simply continued, and that took more work than it looks"
      [World/History] "It has come through the Debt Crisis and the Occupation and simply continued, and that took more work than it looks"

## A37 · src/generators/narrativeText.js · POLITICAL_FLAVOR.stable 'travellers' (two majors, new) · ≥ 2 major events; crisis any · prints in 61 towns (thorp,hamlet,town,city,metropolis,village)

### r2s-under_siege-thorp-3
    tier thorp pop 7 · crisis under_siege · prosperity Struggling · route river · terrain forest
    powers 1: Household Council[government 100] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)"]
    history: The Purge(major,142y,occupation_infiltration); The Religious Conflict(major,115y,religious); The Migration(major,5y,demographic)
    PAGE: [Summary/Overview] "It has come through the Purge and the Religious Conflict, and travellers still remember the place kindly"
      [World/History] "It has come through the Purge and the Religious Conflict, and travellers still remember the place kindly"

### r2r-hamlet-24
    tier hamlet pop 100 · crisis famine · prosperity Struggling · route isolated · terrain mountain
    powers 1: Headman's Authority[government 100] · govt 
    houses (8) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: The Purge(major,79y,occupation_infiltration); The Succession Crisis(major,66y,political); The Economic Divide(major,39y,economic); The Migration(minor,7y,demographic)
    PAGE: [Summary/Overview] "It has come through the Purge and the Succession Crisis, and travellers still remember the place kindly"
      [World/History] "It has come through the Purge and the Succession Crisis, and travellers still remember the place kindly"

### r2s-occupied-thorp-2
    tier thorp pop 28 · crisis occupied · prosperity Poor · route port · terrain coastal
    powers 2: Occupation Authority[military 53]; Elder Council[government 47] · govt 
    houses (9) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":3} · exports ["Salted fish (taxed by occupation)","Smoked seafood (taxed by occupation)","Fish oil (taxed by occupation)","Recovered artefacts (taxed by occupation)"] imports []
    history: The Pilgrimage(major,69y,religious); The Purge(major,49y,occupation_infiltration)
    PAGE: [Summary/Overview] "It has come through the Pilgrimage and the Purge, and travellers still remember the place kindly"
      [World/History] "It has come through the Pilgrimage and the Purge, and travellers still remember the place kindly"

### rr3-thorp-insurgency-rand-3
    tier thorp pop 6 · crisis insurgency · prosperity Struggling · route road · terrain plains
    powers 1: Elder Council[government 100] · govt 
    houses (5) key: Access to external mill
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Reeds and thatch","Peat fuel","Waterfowl","Transit trade","Toll revenue"] imports ["Salt"]
    history: The Great Fire(major,203y,disaster); The Schism(minor,120y,political); The Purge(major,50y,occupation_infiltration)
    PAGE: [Summary/Overview] "It has come through the Great Fire and the Purge, and travellers still remember the place kindly"
      [World/History] "It has come through the Great Fire and the Purge, and travellers still remember the place kindly"

### rr3-metropolis-politically_fractured-rand-1
    tier metropolis pop 53075 · crisis politically_fractured · prosperity Moderate · route river · terrain riverside
    powers 9: Noble Houses[noble 17]; Thieves' Guild[criminal 16]; The Independent Bloc[other 13]; Ducal Governorship[government 11]; Military/Guard[military 11]; Merchant Guilds[economy 10]; Third Bloc (Neutrals)[other 9]; Craft Guilds[economy 7]; The Martial Alliance[military 6] · govt 
    houses (98) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Docks/port facilities; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild; Elder Grove Council
    food: sources ["fish","mill"] failed null granary true · balance {"imp":44867} · exports ["Milled flour","Healing waters (bottled)","Pilgrim hospitality","Quarried stone","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Wool","Livestock and dairy (local pastures depleted)","Timber (local forests cleared)","Bulk grain (local fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials"]
    history: The Siege(major,635y,disaster); The Great Fire(major,552y,disaster); The Interregnum(catastrophic,545y,political); The Plague Years(major,502y,disaster); The Migration(minor,458y,demographic); The Land Dispute(major,433y,political); The Schism(minor,394y,political); The Uprising(major,329y,political); The Heresy Trials(major,265y,religious); The Purge(major,249y,occupation_infiltration); The Tyranny(catastrophic,170y,political); The Occupation(catastrophic,151y,exile_return); The Arcane Incident(major,113y,magical); The Economic Divide(minor,56y,economic); The Succession Crisis(minor,6y,political)
    PAGE: [Summary/Overview] "It has come through the Siege and the Great Fire, and travellers still remember the place kindly"
      [World/History] "It has come through the Siege and the Great Fire, and travellers still remember the place kindly"

## A38 · src/generators/narrativeText.js · POLITICAL_FLAVOR.stable 'date things by' (two majors, new) · ≥ 2 major events, < the many-events branch · prints in 16 towns (thorp,hamlet,village,city,town)

### r2s-under_siege-hamlet-2
    tier hamlet pop 94 · crisis under_siege · prosperity Struggling · route river · terrain plains
    powers 1: Headman's Authority[government 100] · govt 
    houses (11) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources ["grain","fish"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)","Incense and votive candles"]
    history: The Purge(major,27y,occupation_infiltration); The Iron Dispute(major,18y,economic)
    PAGE: [Summary/Overview] "The Purge and the Iron Dispute are the events people here still date things by"
      [World/History] "The Purge and the Iron Dispute are the events people here still date things by"

### rr3-town-famine-rand-1
    tier town pop 1122 · crisis famine · prosperity Struggling · route road · terrain hills
    powers 4: Arcane Council[magic 31]; Thieves' Guild[criminal 29]; Military/Guard[military 21]; Merchant Guilds[economy 19] · govt 
    houses (31) key: Fish market; Weekly market; Market square; Merchant guilds (3-8); Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Monastery or friary; Elder Grove Council; Town hall; Town walls; Town watch; Teleportation circle
    food: sources [] failed null granary true · balance {"imp":877} · exports ["Sacred wood","Ritual components","Coal","Reeds and thatch","Waterfowl","Magical item market","Weapon enchantment","Pilgrimage & religious tourism"] imports ["Timber (local forests cleared)","Iron","Grain","Salt","Replacement arms and basic equipment","Incense, ritual oil, sacred texts, and vestment cloth (bulk)","Alchemical reagents and scribal supplies","Sulfur and brimstone","Stolen silver"]
    history: The Purge(major,63y,occupation_infiltration); The Economic Divide(major,34y,economic)
    PAGE: [Summary/Overview] "The Purge and the Economic Divide are the events people here still date things by"
      [World/History] "The Purge and the Economic Divide are the events people here still date things by"

### r2r-thorp-7
    tier thorp pop 9 · crisis none · prosperity Poor · route road · terrain mountain
    powers 1: Elder Council[government 100] · govt 
    houses (8) key: Access to external mill; Wayside shrine
    food: sources [] failed null granary false · balance {"imp":1} · exports ["Raw wool","Live sheep","Mineral salts","Alum","Sulfur","Sacred wood","Ritual components","Coal"] imports ["Salt"]
    history: The Plague Years(major,59y,disaster); The Purge(major,32y,occupation_infiltration)
    PAGE: [Summary/Overview] "The Plague Years and the Purge are the events people here still date things by"
      [World/History] "The Plague Years and the Purge are the events people here still date things by"

### r2r-city-20
    tier city pop 12918 · crisis none · prosperity Comfortable · route isolated · terrain mountain
    powers 4: Ecclesiastical Council[religious 43]; Religious Authorities[religious 29]; Arcane Orders[magic 12]; The Devout Circle[religious 16] · govt 
    houses (61) key: Daily markets; Multiple market squares; City granaries; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; Mayor and council; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Black market; Tailor's guild; Teleportation circle; Multiple adventurers' guilds
    food: sources [] failed null granary true · balance {"imp":9994} · exports ["Raw wool","Live sheep","Pine planks","Charcoal","Toll revenue","Pass transit trade","Precious metals","Processed textiles","Guild-manufactured goods","Barrels and containers","Quality tools and weapons","Legal services (contracts, notarial)","Military contract services","Cultural tourism revenue"] imports ["Iron","Wool","Timber (local forests cleared)","Grain","Medicinal herbs","Luxury textiles and exotic goods","Incense, ritual oil, and vestment materials","Alchemical reagents and scribal supplies","Copal resin incense","Jade and turquoise for ritual"]
    history: The Religious Conflict(major,122y,religious); The Occupation(major,77y,exile_return)
    PAGE: [Summary/Overview] "The Religious Conflict and the Occupation are the events people here still date things by"
      [World/History] "The Religious Conflict and the Occupation are the events people here still date things by"
