# Reading sheet C01,C02,C03,C04,C05,C06,C08,C10,C11

## C01 · src/domain/crisis/crisisSummaryVantage.js · CRISIS_SUMMARY_POOLS.plague_onset.defence.watch · plague_onset; the town's hashed column is 'watch' on the Defence surface · prints in 10 towns (thorp,hamlet,town,city,metropolis)

### rr3-thorp-plague_onset-rand-5
    tier thorp pop 6 · crisis plague_onset · prosperity Struggling · route port · terrain coastal
    powers 1: Elder Council[government 100] · govt 
    houses (6) key: Access to external mill
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports ["Salted fish","Smoked seafood","Fish oil","Recovered artefacts"] imports ["Medicinal herbs"]
    history: The Debt Crisis(major,113y,economic); The Occupation(major,84y,exile_return); The Schism(minor,43y,political)
    PAGE: [Systems/Defense] Those trying to keep Lyssoichi's sick apart from the healthy are being resisted, and not everyone keeps the quarantine.

### r2s-plague_onset-metropolis-3
    tier metropolis pop 27673 · crisis plague_onset · prosperity Moderate · route river · terrain forest
    powers 8: Religious Authorities[religious 32]; Ducal Governorship[government 20]; Arcane Orders[magic 12]; Noble Houses[noble 10]; Military/Guard[military 9]; Merchant Guilds[economy 6]; Quarantine Council[government 6]; The Peerage[noble 5] · govt 
    houses (100) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Teleportation circle; Multiple adventurers' guilds; Whisper market; Black market bazaar; Airship docking (high magic)
    food: sources ["livestock","fish"] failed null granary true · balance {"imp":28409} · exports ["Raw wool","Livestock","Healing waters (bottled)","Pilgrim hospitality","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","Extraplanar goods","Planar travel information","News and information","Maps and charts","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)","Planar trade access"] imports ["Iron ore (local iron mines exhausted)","Timber (local managed woodland cleared)","Dressed stone (local quarry depleted)","Grain","Medicinal herbs","Paper","Paper materials","Precious metals","Clay and raw materials","Ritual wood and herbs (ancient grove damaged)"]
    history: The Succession Crisis(minor,376y,political); The Scandal(major,353y,political); The Great Fire(catastrophic,328y,disaster); The Land Dispute(major,305y,political); The Flood(catastrophic,288y,disaster); The Trade Collapse(major,278y,economic); The Interregnum(catastrophic,260y,political); The Occupation(catastrophic,229y,exile_return); The Heresy Trials(minor,215y,religious); The Arcane Incident(major,189y,magical); The Plague Years(major,152y,disaster); The Purge(major,133y,political); The Debt Crisis(major,108y,economic); The Wild Magic(minor,66y,magical); The Pilgrimage(major,42y,religious); The Migration(major,24y,demographic); The Siege(major,20y,disaster)
    PAGE: [Systems/Defense] Those trying to keep Umagrad's sick apart from the healthy are being resisted, and not everyone keeps the quarantine.

### r2s-plague_onset-thorp-3
    tier thorp pop 15 · crisis plague_onset · prosperity Comfortable · route road · terrain plains
    powers 1: Household Council[government 100] · govt 
    houses (7) key: Access to external mill
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Sacred wood","Ritual components"] imports ["Salt","Medicinal herbs"]
    history: The Crash(major,208y,economic); The Succession Crisis(minor,44y,political)
    PAGE: [Systems/Defense] Those trying to keep Dharmaghat's sick apart from the healthy are being resisted, and not everyone keeps the quarantine.

### r2s-plague_onset-hamlet-1
    tier hamlet pop 35 · crisis plague_onset · prosperity Struggling · route road · terrain plains
    powers 1: Elder Council[government 100] · govt 
    houses (10) key: Periodic market; Access to external mill; Access to parish church; Palisade or earthworks; Citizen militia
    food: sources [] failed null granary false · balance {"imp":3} · exports ["Sacred wood","Ritual components","Coal","Recovered artefacts"] imports ["Salt","Medicinal herbs","Replacement arms and basic equipment","Incense and votive candles"]
    history: The Siege(catastrophic,38y,disaster)
    PAGE: [Systems/Defense] Those trying to keep Weichsee's sick apart from the healthy are being resisted, and not everyone keeps the quarantine.

## C02 · src/domain/dailyLife.js · deriveChildWarnings (a warning said once) · two threats of one warning · prints in 225 towns (thorp,hamlet,village,town,city,metropolis)

### rr3-town-under_siege-rand-0
    tier town pop 1598 · crisis under_siege · prosperity Struggling · route road · terrain hills
    powers 3: Military Council[military 63]; Military/Guard[military 21]; Religious Authorities[religious 16] · govt 
    houses (27) key: Weekly market; Market square; Merchant guilds (3-8); Town granary; Mills (2-5); Tailor's guild; Craft guilds (5-15); Parish churches (2-5); Town hall; Courthouse; Town watch; Bowyers & fletchers (guild)
    food: sources [] failed null granary true · balance {"imp":0} · exports ["Quality tools and weapons","Legal services (contracts, notarial)"] imports ["Timber (local managed woodland cleared)","Grain","Salt","Iron (weapons)","Preserved provisions","Reeds, peat, and marsh herbs (local wetlands exhausted)","Coal and fuel (local seams exhausted)","Incense, ritual oil, and vestment materials","Cavalry horses and tack","Salted provisions and hardtack"]
    history: The Religious Conflict(minor,59y,religious); The Iron Dispute(major,34y,economic); The Succession Crisis(minor,29y,political); The Migration(major,16y,demographic)
    PAGE: (NOT ON THE PAGE)

### r2s-succession_void-thorp-1
    tier thorp pop 11 · crisis succession_void+famine · prosperity Struggling · route isolated · terrain forest
    powers 1: Elder Council[government 100] · govt 
    houses (6) key: Access to external mill; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: The Occupation(catastrophic,153y,exile_return); The Schism(minor,40y,political)
    PAGE: (NOT ON THE PAGE)

### r2s-occupied-town-0
    tier town pop 1580 · crisis occupied · prosperity Poor · route road · terrain hills
    powers 4: Occupation Authority[military 41]; Town Council[government 28]; Resistance Network[military 17]; Merchant Guilds[economy 14] · govt 
    houses (33) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Adventurers' charter hall; Hireling hall; Town walls; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":870} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Sacred wood (taxed by occupation)","Ritual components (taxed by occupation)","Legal services (contracts, notarial)"] imports ["Wool","Iron","Grain","Salt","Livestock and dairy (local grazing land depleted)","Quality weapons and armour","Incense and votive candles","Lorica segmentata fittings","Fine wine and amphorae"]
    history: The Succession Crisis(minor,97y,political); The Migration(major,63y,demographic); The Purge(major,29y,occupation_infiltration); The Arcane Incident(minor,19y,magical)
    PAGE: (NOT ON THE PAGE)

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local grain fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: (NOT ON THE PAGE)

## C03 · src/domain/dailyLife.js · deriveOutsiderImpressions (powerPossessive) · a dominant faction · prints in 351 towns (hamlet,village,town,city,metropolis)

### r2s-under_siege-town-1
    tier town pop 1339 · crisis under_siege · prosperity Struggling · route road · terrain desert
    powers 3: Religious Authorities[religious 49]; War Council[military 27]; Guild Council[economy 24] · govt 
    houses (39) key: Fish market; Weekly market; Market square; Merchant guilds (3-8); Carriers' guild; Town granary; Mills (2-5); Tailor's guild; Craft guilds (5-15); Parish churches (2-5); Guild governance; Town hall; Town watch; Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":0} · exports [] imports ["Iron (weapons)","Grain","Salt (local desert pans exhausted)","Warehousing and logistics services","Glass sand (local sand pits exhausted)","Incense and votive candles","Incense and ritual paper","Bowstaves and horn"]
    history: The Religious Conflict(major,112y,religious); The Occupation(major,105y,exile_return); The Economic Divide(major,71y,economic); The Purge(major,12y,occupation_infiltration)
    PAGE: (NOT ON THE PAGE)

### r2r-city-44
    tier city pop 2408 · crisis famine · prosperity Struggling · route river · terrain coastal
    powers 5: Religious Authorities[religious 31]; Military/Guard[military 24]; Ecclesiastical Council[religious 15]; The Order of the Watch[military 13]; The Holy Compact[religious 17] · govt 
    houses (39) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Barge and river transport company; Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Sawmill (commercial); Craft guilds (30-80); Parish churches (10-30); Multiple monasteries; City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Black market
    food: sources ["fish"] failed fish granary true · balance {"imp":2178} · exports ["Salted fish","Smoked seafood","Fish oil","Medicinal herbs","Wild honey","Sacred wood","Ritual components","Luxury manufactured goods","Fine metalwork and jewelry","Herbal remedies","Potions and elixirs","Rare spices and exotic dyes","Quality tools and weapons","Legal services (contracts, notarial)","Military contract services","Waterborne freight services (cargo, pilotage)"] imports ["Iron","Grain","Salt","Cut stone and masonry","Clay and raw materials","Luxury textiles and exotic goods","Coal and fuel (local seams exhausted)","Incense, ritual oil, and vestment materials","Cordage, tar, timber fittings, and bulk vessel supplies","Fine pottery for libations"]
    history: The Heresy Trials(minor,120y,religious); The Religious Conflict(minor,112y,religious); The Great Construction(major,84y,economic); The Purge(major,83y,occupation_infiltration); The Siege(catastrophic,61y,disaster); The Succession Crisis(minor,31y,political); The Occupation(major,8y,exile_return)
    PAGE: (NOT ON THE PAGE)

### r2s-occupied-village-2
    tier village pop 386 · crisis occupied · prosperity Poor · route crossroads · terrain riverside
    powers 3: Merchant Guilds[economy 39]; Occupation Authority[military 32]; Household Council[government 29] · govt 
    houses (14) key: Fish market; Weekly market; Mill; Parish church; Priest (resident); Adventurers' charter hall
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":9} · exports ["River fish (taxed by occupation)","Freshwater catch (taxed by occupation)","Raw wool (taxed by occupation)","Livestock (taxed by occupation)","Transit trade (taxed by occupation)"] imports ["Replacement arms and basic equipment","Incense and votive candles","Bronze fittings and tools"]
    history: The Purge(major,16y,occupation_infiltration)
    PAGE: (NOT ON THE PAGE)

### rr3-hamlet-insurgency-rand-1
    tier hamlet pop 70 · crisis insurgency · prosperity Struggling · route crossroads · terrain hills
    powers 2: Military/Guard[military 53]; Feudal Stewardship[government 47] · govt 
    houses (13) key: Access to external mill; Access to parish church; Citizen militia
    food: sources ["livestock"] failed null granary false · balance {"imp":0} · exports ["Raw wool","Livestock","Transit trade","Toll revenue","Coal","Preserved foods"] imports ["Salt","Replacement arms and basic equipment","Incense and votive candles"]
    history: The Succession Crisis(major,66y,political); The Occupation(major,36y,exile_return)
    PAGE: (NOT ON THE PAGE)

### r2s-succession_void-metropolis-3
    tier metropolis pop 295750 · crisis succession_void · prosperity Wealthy · route road · terrain mountain
    powers 10: Merchant Guilds[economy 17]; Grand Merchant Senate[economy 16]; Religious Authorities[religious 14]; Craft Guilds[economy 10]; Arcane Orders[magic 10]; Military/Guard[military 9]; The Highborn Circle[noble 8]; The Peerage[noble 7]; Noble Houses[noble 6]; The Landed Bloc[noble 3] · govt 
    houses (95) key: Fish market; District markets (5-10); Multiple market squares; State granary complex; Mills (2-5); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; Mayor and council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Assassins' guild; Merchant guilds (50-100+)
    food: sources [] failed null granary true · balance {"imp":317058} · exports ["Coal","Reeds and thatch","Waterfowl","Spellcasting (minor)","Magical identification","News and information","Maps and charts","Glassware","Books and manuscripts","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Timber (local mountain timber cleared)","Wool","Stone","Iron","Grain","Medicinal herbs","Paper","Paper materials","Salt","Preserved provisions"]
    history: The Tyranny(major,742y,political); The Pilgrimage(major,696y,religious); The Crash(major,627y,economic); The Trade Collapse(major,609y,economic); The Land Dispute(minor,563y,political); The Debt Crisis(major,517y,economic); The Guild War(minor,458y,economic); The Great Fire(catastrophic,408y,disaster); The Heresy Trials(major,352y,religious); The Plague Years(catastrophic,295y,disaster); The Purge(major,255y,political); The Religious Conflict(minor,211y,religious); The Economic Divide(minor,169y,economic); The Migration(minor,146y,demographic); The Occupation(catastrophic,112y,exile_return); The Succession Crisis(minor,69y,political); The Arcane Incident(minor,5y,magical)
    PAGE: (NOT ON THE PAGE)

## C04 · src/domain/dailyLife.js · deriveUnspokenTopics (a topic said once) · — · prints in 128 towns (village,town,city,hamlet,metropolis)

### rr3-village-under_siege+famine-rand-2
    tier village pop 112 · crisis under_siege+famine · prosperity Struggling · route road · terrain mountain
    powers 2: Elder Council[government 61]; War Council[military 39] · govt 
    houses (11) key: Mill; Parish church; Priest (resident)
    food: sources ["livestock"] failed livestock granary false · balance {"imp":0} · exports [] imports ["Salt","Grain","Iron (weapons)","Incense and votive candles","Quetzal feathers and jade"]
    history: The Economic Divide(major,38y,economic); The Siege(major,6y,disaster)
    PAGE: (NOT ON THE PAGE)

### r2s-famine-city-0
    tier city pop 2909 · crisis famine · prosperity Struggling · route river · terrain riverside
    powers 5: Noble Families[noble 27]; Royal Authority[government 24]; Military/Guard[military 23]; The Shield Compact[military 12]; The Landed Bloc[noble 14] · govt 
    houses (37) key: Fish market; Daily markets; Multiple market squares; Merchant guilds (15-40); Docks/port facilities; Harbour master's office; City granaries; Mills (2-5); Sawmill (commercial); Cobbler's guild; Craft guilds (30-80); Parish churches (10-30); City hall; Multiple courthouses; City walls and gates; Professional city watch; Garrison; Barge and river transport company
    food: sources ["fish","mill"] failed fish granary true · balance {"imp":2366} · exports ["River fish","Freshwater catch","Sacred wood","Ritual components","Milled timber","Milled flour","Salted fish","Smoked seafood","Legal services (contracts, notarial)","Military contract services","Cultural tourism revenue","Waterborne freight services (cargo, pilotage)","Scholarly services (research access, rare texts)"] imports ["Bulk grain (local grain fields depleted)","Capital","Salt","Iron ore","Charcoal and fuel","Preserved provisions","Route maps and intelligence","Luxury textiles and exotic goods","Reeds, peat, and marsh herbs (local wetlands exhausted)","Incense and votive candles"]
    history: The Land Dispute(minor,203y,political); The Guild War(major,182y,economic); The Purge(major,152y,occupation_infiltration); The Arcane Incident(minor,128y,magical); The Occupation(major,126y,exile_return); The Shortage(major,88y,economic); The Debt Crisis(major,63y,economic); The Siege(major,47y,disaster); The Succession Crisis(minor,27y,political); The Migration(major,9y,demographic)
    PAGE: (NOT ON THE PAGE)

### r2s-occupied-town-0
    tier town pop 1580 · crisis occupied · prosperity Poor · route road · terrain hills
    powers 4: Occupation Authority[military 41]; Town Council[government 28]; Resistance Network[military 17]; Merchant Guilds[economy 14] · govt 
    houses (33) key: Weekly market; Market square; Town granary; Mills (2-5); Craft guilds (5-15); Parish churches (2-5); Town council; Town hall; Courthouse; Town watch; Adventurers' charter hall; Hireling hall; Town walls; Merchant guilds (3-8); Bowyers & fletchers (guild); Cobbler's guild
    food: sources [] failed null granary true · balance {"imp":870} · exports ["Reeds and thatch (taxed by occupation)","Peat fuel (taxed by occupation)","Waterfowl (taxed by occupation)","Sacred wood (taxed by occupation)","Ritual components (taxed by occupation)","Legal services (contracts, notarial)"] imports ["Wool","Iron","Grain","Salt","Livestock and dairy (local grazing land depleted)","Quality weapons and armour","Incense and votive candles","Lorica segmentata fittings","Fine wine and amphorae"]
    history: The Succession Crisis(minor,97y,political); The Migration(major,63y,demographic); The Purge(major,29y,occupation_infiltration); The Arcane Incident(minor,19y,magical)
    PAGE: (NOT ON THE PAGE)

### rr3-hamlet-mass_migration-port-1
    tier hamlet pop 34 · crisis mass_migration · prosperity Moderate · route port · terrain coastal
    powers 2: Headman's Authority[government 77]; Newcomers' Settlement[other 23] · govt 
    houses (12) key: Access to external mill; Access to parish church
    food: sources ["fish"] failed null granary false · balance {"imp":7} · exports ["Magical services","Potions and elixirs"] imports ["Incense and votive candles"]
    history: The Succession Crisis(major,68y,political); The Purge(major,40y,occupation_infiltration); The Economic Divide(minor,15y,economic)
    PAGE: (NOT ON THE PAGE)

### rr3-metropolis-mass_migration-rand-3
    tier metropolis pop 29939 · crisis mass_migration · prosperity Prosperous · route port · terrain coastal
    powers 8: Grand Guild Consortium[economy 35]; Merchant Guilds[economy 20]; Craft Guilds[economy 11]; Military/Guard[military 8]; Arcane Orders[magic 8]; Newcomers' Settlement[other 8]; The Enlightened[magic 4]; The Commercial Circle[economy 6] · govt 
    houses (87) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Docks/port facilities; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Guild consortium; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market
    food: sources ["fish"] failed null granary true · balance {"imp":36902} · exports ["Ship passage","Maritime trade access","Maritime trade revenue","Ship construction","Luxury manufactured goods","Fine metalwork and jewelry","Glassware","Books and manuscripts","Rare spices and exotic dyes","Fine textiles","Furs and pelts","Meals and drink","Financial services (letters of credit)","Legal services (contracts, notarial)","Military contract services","Cultural tourism revenue","Maritime services (cargo, pilotage)","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Paper materials","Shipbuilding timber (local shipbuilding stands cleared)","Precious metals","Iron","Grain","Medicinal herbs","Luxury materials","Luxury textiles and exotic goods","Recovered artefacts (local ruins exhausted)","Salted fish (local sea fisheries exhausted)"]
    history: The Economic Divide(minor,354y,economic); The Crash(major,288y,economic); The Trade Collapse(major,282y,economic); The Purge(major,197y,occupation_infiltration); The Siege(catastrophic,143y,disaster); The Shortage(major,96y,economic); The Arcane Incident(major,74y,magical); The Migration(major,53y,political)
    PAGE: (NOT ON THE PAGE)

## C05 · src/domain/dailyLife.js · deriveRecentChanges (no 'Recent changes:' in the text; first letter capitalised) · any change · prints in 1495 towns (thorp,hamlet,village,town,city,metropolis)

### r2r-thorp-45
    tier thorp pop 20 · crisis under_siege · prosperity Struggling · route river · terrain forest
    powers 1: Household Council[government 100] · govt 
    houses (9) key: Access to external mill; Palisade
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)"]
    history: The Great Fire(catastrophic,154y,disaster); The Migration(minor,11y,demographic)
    PAGE: [Summary/Overview] Weißgassethorp· 20 pop.· river· 163 years old
      [Summary/Overview] Germanic-inspired, and it shows: built in timber and stone, and run by its estates. Governed by Household Council · Critical (under siege); monsters on the roads
      [Summary/Overview] "Older residents still distinguish between 'the original settlement' and 'what we have now'. The Great Fire is where that line falls, not a clean line, but a real one"
      [Summary/Overview] Forest
      [Summary/Overview] Open Tonight
      [Summary/Overview] The place

### r2r-thorp-17
    tier thorp pop 11 · crisis famine · prosperity Struggling · route isolated · terrain hills
    powers 1: Household Council[government 100] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["game"] failed game granary false · balance {"imp":0} · exports [] imports []
    history: The Migration(minor,142y,demographic); The Great Construction(major,125y,economic); The Occupation(catastrophic,101y,exile_return); The Purge(major,21y,occupation_infiltration)
    PAGE: [Summary/Overview] Chichichthorp· 11 pop.· isolated· 193 years old
      [Summary/Overview] Mesoamerican-inspired, and it shows: built around a civic-ritual plaza, on tribute and the ritual calendar. Governed by Household Council · Desperate — hunger is eroding order; monsters on the roads
      [Summary/Overview] "This place is older than the Occupation, but people here date everything from it: before it, and after"
      [Summary/Overview] Hills
      [Summary/Overview] Open Tonight
      [Summary/Overview] The place

### r2r-thorp-1
    tier thorp pop 30 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Occupation Authority[military 57]; Elder Council[government 43] · govt 
    houses (11) key: Access to external mill; Access to parish church; Palisade
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)","Contraband goods (transit) (taxed by occupation)"] imports []
    history: The Economic Divide(major,208y,economic); The Purge(major,179y,occupation_infiltration); The Uprising(major,39y,political)
    PAGE: [Summary/Overview] Terrapolisthorp· 30 pop.· river· 284 years old
      [Summary/Overview] Latin-inspired, and it shows: built in masonry around a civic square, and run by patronage and law. Governed by Elder Council · Suppressed (under occupation: resistance simmers); monsters on the roads
      [Summary/Overview] "This place made its name in trade, not war, and the Economic Divide showed it that money lasts longer here than any military glory"
      [Summary/Overview] Riverside
      [Summary/Overview] Open Tonight
      [Summary/Overview] The place

### r2r-thorp-36
    tier thorp pop 5 · crisis none · prosperity Poor · route river · terrain riverside
    powers 1: Elder Council[government 100] · govt 
    houses (7) key: Access to external mill; Access to parish church
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":0} · exports ["Raw wool","Livestock","Sacred wood","Ritual components","Coal"] imports []
    history: The Purge(major,197y,occupation_infiltration); The Migration(major,81y,demographic); The Occupation(catastrophic,25y,exile_return)
    PAGE: [Summary/Overview] Cnocbridgethorp· 5 pop.· river· 199 years old
      [Summary/Overview] Celtic-inspired: built around kin districts and an assembly ground, on pasture. Governed by Elder Council · Stable
      [Summary/Overview] "The Occupation is this place's defining story, and the people who lived through it are still here to tell it"
      [Summary/Overview] Riverside
      [Summary/Overview] Open Tonight
      [Summary/Overview] The place

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local grain fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Overview] Langenbergmetropolis· 344,689 pop.· river· 356 years old
      [Summary/Overview] Germanic-inspired: built in timber and stone, and run by guild and estate. Governed by Royal Authority · Volatile — power is available to whoever moves first
      [Summary/Overview] "The Occupation changed what people here believe can happen to them, and that has been slower to rebuild than any building"
      [Summary/Overview] Riverside
      [Summary/Overview] Open Tonight
      [Summary/Overview] The place

## C06 · src/domain/display/conditionWords.js · activeConditionWords (a generation-promoted condition named by its crisis) · a crisis in force · prints in 1247 towns (thorp,hamlet,village,town,city,metropolis)

### r2r-thorp-45
    tier thorp pop 20 · crisis under_siege · prosperity Struggling · route river · terrain forest
    powers 1: Household Council[government 100] · govt 
    houses (9) key: Access to external mill; Palisade
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)"]
    history: The Great Fire(catastrophic,154y,disaster); The Migration(minor,11y,demographic)
    PAGE: [Summary/Foundations] This reading includes the current condition: under siege.

### r2r-thorp-17
    tier thorp pop 11 · crisis famine · prosperity Struggling · route isolated · terrain hills
    powers 1: Household Council[government 100] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["game"] failed game granary false · balance {"imp":0} · exports [] imports []
    history: The Migration(minor,142y,demographic); The Great Construction(major,125y,economic); The Occupation(catastrophic,101y,exile_return); The Purge(major,21y,occupation_infiltration)
    PAGE: [Summary/Foundations] This reading includes the current condition: famine.

### r2r-thorp-1
    tier thorp pop 30 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Occupation Authority[military 57]; Elder Council[government 43] · govt 
    houses (11) key: Access to external mill; Access to parish church; Palisade
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)","Contraband goods (transit) (taxed by occupation)"] imports []
    history: The Economic Divide(major,208y,economic); The Purge(major,179y,occupation_infiltration); The Uprising(major,39y,political)
    PAGE: [Summary/Foundations] This reading includes the current condition: under occupation.

### rr3-thorp-under_siege-rand-4
    tier thorp pop 5 · crisis under_siege · prosperity Struggling · route river · terrain riverside
    powers 1: Household Council[government 100] · govt 
    houses (6) key: Access to external mill
    food: sources ["fish","game"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)"]
    history: The Migration(major,171y,demographic); The Great Construction(major,138y,economic); The Purge(major,97y,occupation_infiltration); The Occupation(major,61y,political)
    PAGE: [Summary/Foundations] This reading includes the current condition: under siege.

### r2r-metropolis-8
    tier metropolis pop 344689 · crisis succession_void · prosperity Comfortable · route river · terrain riverside
    powers 7: Royal Authority[government 22]; Religious Authorities[religious 20]; Thieves' Guild[criminal 16]; Noble Claimant (Senior Line)[noble 15]; Noble Claimant (Reform Line)[noble 12]; The Highborn Circle[noble 7]; The Peerage[noble 8] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); Barge and river transport company; Harbour master's office; State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Major monasteries (5-10); Elder Grove Council; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Thieves' guild (powerful); Whisper market; Assassins' guild
    food: sources ["fish","mill"] failed null granary true · balance {"imp":288908} · exports ["Milled flour","Fulled cloth","Healing waters (bottled)","Pilgrim hospitality","Iron ore","Weapons and armour","News and information","Maps and charts","Luxury manufactured goods","Fine metalwork and jewelry","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Livestock","Dressed stone (local quarry depleted)","Bulk grain (local grain fields depleted)","Medicinal herbs","Paper","Paper materials","Luxury materials","Precious metals","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Schism(minor,282y,political); The Religious Conflict(minor,237y,religious); The Heresy Trials(major,212y,religious); The Trade Collapse(major,188y,economic); The Migration(major,167y,political); The Succession Crisis(minor,129y,political); The Pilgrimage(major,98y,religious); The Arcane Incident(major,64y,magical); The Purge(major,21y,occupation_infiltration); The Occupation(catastrophic,13y,exile_return)
    PAGE: [Summary/Foundations] This reading includes the current condition: succession void.

## C08 · src/generators/factionDynamics.js · computeFactionRelationships, occupier row · an appointed power of a crisis in force is the military faction · prints in 110 towns (thorp,hamlet,village,town,city,metropolis)

### r2s-occupied-thorp-1
    tier thorp pop 17 · crisis occupied+famine · prosperity Struggling · route isolated · terrain mountain
    powers 2: Occupation Authority[military 56]; Elder Council[government 44] · govt 
    houses (8) key: Access to external mill; Wayside shrine; Access to parish church
    food: sources [] failed null granary false · balance {"imp":0} · exports [] imports []
    history: The Siege(major,186y,disaster); The Pilgrimage(minor,122y,religious); The Migration(major,87y,demographic)
    PAGE: [Systems/Power] Elder Council carries out what Occupation Authority decides.

### r2r-thorp-1
    tier thorp pop 30 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Occupation Authority[military 57]; Elder Council[government 43] · govt 
    houses (11) key: Access to external mill; Access to parish church; Palisade
    food: sources [] failed null granary false · balance {"imp":0} · exports ["Medicinal herbs (taxed by occupation)","Wild honey (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)","Contraband goods (transit) (taxed by occupation)"] imports []
    history: The Economic Divide(major,208y,economic); The Purge(major,179y,occupation_infiltration); The Uprising(major,39y,political)
    PAGE: [Systems/Power] Elder Council carries out what Occupation Authority decides.

### r2s-occupied-thorp-0
    tier thorp pop 13 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Household Council[government 51]; Occupation Authority[military 49] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["fish"] failed null granary false · balance {"imp":1} · exports ["River fish (taxed by occupation)","Freshwater catch (taxed by occupation)","Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)"] imports []
    history: The Guild War(major,68y,economic); The Migration(minor,5y,demographic)
    PAGE: [Systems/Power] Household Council carries out what Occupation Authority decides.

### rr3-metropolis-occupied-rand-3
    tier metropolis pop 301467 · crisis occupied · prosperity Poor · route crossroads · terrain hills
    powers 8: Grand Guild Consortium[economy 22]; Merchant Guilds[economy 20]; Occupation Authority[military 14]; Craft Guilds[economy 13]; Arcane Orders[magic 13]; Resistance Network[military 6]; Military/Guard[military 5]; The Tower Alliance[magic 7] · govt 
    houses (92) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Tailor's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); Guild consortium; City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Elder Grove Council
    food: sources ["livestock"] failed null granary true · balance {"imp":377246} · exports ["Raw wool (taxed by occupation)","Livestock (taxed by occupation)","Transit trade (taxed by occupation)","Toll revenue (taxed by occupation)","Iron ore (taxed by occupation)","Financial services (letters of credit)","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Educational services (degrees, training)","Military contract services","Arcane services (identification, enchanting)","Cultural tourism revenue","Scholarly services (research access, rare texts)"] imports ["Precious metals","Grain","Paper","Paper materials","Dressed stone (local quarry depleted)","Salt","Precious metals and bullion","Preserved provisions","Clay and raw materials","Coal and fuel (local seams exhausted)"]
    history: The Debt Crisis(major,747y,economic); The Wild Magic(minor,685y,magical); The Guild War(minor,634y,economic); The Trade Collapse(major,533y,economic); The Shortage(major,408y,economic); The Flood(major,355y,disaster); The Migration(minor,303y,political); The Economic Divide(minor,229y,economic); The Crash(major,212y,economic); The Great Fire(catastrophic,171y,disaster); The Purge(major,117y,occupation_infiltration); The Arcane Incident(minor,88y,magical); The Succession Crisis(major,41y,political); The Occupation(catastrophic,29y,exile_return)
    PAGE: [Systems/Power] Grand Guild Consortium carries out what Occupation Authority decides.

## C10 · src/generators/structuralValidator.js · survival_crisis error · embattled; military priority < the error cut · prints in 0 towns ()

## C11 · src/generators/structuralValidator.js · survival_crisis warning · embattled; military priority < 40 · prints in 107 towns (thorp,hamlet,village,city,metropolis,town)

### r2r-thorp-45
    tier thorp pop 20 · crisis under_siege · prosperity Struggling · route river · terrain forest
    powers 1: Household Council[government 100] · govt 
    houses (9) key: Access to external mill; Palisade
    food: sources ["livestock","fish"] failed null granary false · balance {"imp":0} · exports [] imports ["Grain","Salt","Iron (weapons)"]
    history: The Great Fire(catastrophic,154y,disaster); The Migration(minor,11y,demographic)
    PAGE: [Systems/Defense] Embattled region. Fortification and forces are present but chronically underfunded: poor equipment, low morale, and thin reinforcement. A beleaguered outpost surviving on the edge.

### r2r-thorp-17
    tier thorp pop 11 · crisis famine · prosperity Struggling · route isolated · terrain hills
    powers 1: Household Council[government 100] · govt 
    houses (10) key: Access to external mill; Access to parish church; Palisade
    food: sources ["game"] failed game granary false · balance {"imp":0} · exports [] imports []
    history: The Migration(minor,142y,demographic); The Great Construction(major,125y,economic); The Occupation(catastrophic,101y,exile_return); The Purge(major,21y,occupation_infiltration)
    PAGE: [Systems/Defense] Embattled region. Fortification and forces are present but chronically underfunded: poor equipment, low morale, and thin reinforcement. A beleaguered outpost surviving on the edge.

### r2r-thorp-27
    tier thorp pop 25 · crisis occupied · prosperity Poor · route river · terrain riverside
    powers 2: Household Council[government 51]; Occupation Authority[military 49] · govt 
    houses (9) key: Access to external mill; Access to parish church; Palisade
    food: sources ["fish"] failed null granary false · balance {"imp":0} · exports ["Healing waters (bottled) (taxed by occupation)","Pilgrim hospitality (taxed by occupation)"] imports []
    history: The Siege(major,201y,disaster); The Schism(minor,136y,political); The Purge(major,52y,occupation_infiltration)
    PAGE: [Systems/Defense] Embattled region. Fortification and forces are present but chronically underfunded: poor equipment, low morale, and thin reinforcement. A beleaguered outpost surviving on the edge.

### r2s-politically_fractured-thorp-2
    tier thorp pop 9 · crisis politically_fractured · prosperity Moderate · route road · terrain plains
    powers 2: The Independent Bloc[other 58]; Elder Council[government 42] · govt 
    houses (12) key: Access to external mill; Wayside shrine; Access to parish church; Palisade
    food: sources ["livestock"] failed null granary false · balance {"imp":0} · exports ["Raw wool","Livestock","Sacred wood","Ritual components"] imports ["Salt"]
    history: The Purge(major,170y,occupation_infiltration); The Siege(major,134y,disaster); The Pilgrimage(minor,48y,religious)
    PAGE: [Systems/Defense] Embattled region. Fortification and forces are present but chronically underfunded: poor equipment, low morale, and thin reinforcement. A beleaguered outpost surviving on the edge.

### r2s-politically_fractured-metropolis-2
    tier metropolis pop 160904 · crisis politically_fractured · prosperity Moderate · route crossroads · terrain plains
    powers 6: Noble Houses[noble 25]; The Independent Bloc[other 24]; Third Bloc (Neutrals)[other 16]; Ducal Governorship[government 13]; The Common Interest[other 13]; The Grey Council[other 9] · govt 
    houses (86) key: Fish market; District markets (5-10); Multiple market squares; Merchant guilds (50-100+); State granary complex; Mills (2-5); Bowyers & fletchers (guild); Sawmill (commercial); Cobbler's guild; Cartographer's guild; Craft guilds (100-150+); Parish churches (50-100+); City hall; Multiple court buildings; Massive walls and fortifications; Professional city watch; Multiple garrisons; Multiple adventurers' guilds; Whisper market; Black market bazaar; Tailor's guild
    food: sources ["livestock"] failed null granary true · balance {"imp":135273} · exports ["Transit trade","Toll revenue","Iron ore","Weapons and armour","Raw wool","Livestock","Spellcasting (minor)","Magical identification","Magical item market","Weapon enchantment","News and information","Legal services (contracts, notarial)","Pilgrimage & religious tourism","Military contract services","Cultural tourism revenue","Scholarly services (research access, rare texts)","Alchemical trade (potions, reagents)"] imports ["Bulk grain (local grain fields depleted)","Paper","Paper materials","Dressed stone (local quarry depleted)","Salt","Precious metals and bullion","Charcoal and fuel","Clay and raw materials","Luxury textiles and exotic goods","Game and hides (local hunting grounds exhausted)"]
    history: The Scandal(major,235y,political); The Crash(minor,214y,economic); The Plague Years(catastrophic,139y,disaster); The Land Dispute(major,115y,political); The Purge(major,104y,occupation_infiltration); The Occupation(catastrophic,79y,exile_return); The Siege(catastrophic,47y,disaster); The Succession Crisis(minor,9y,political)
    PAGE: [Systems/Defense] Embattled region. Fortification and forces are present but chronically underfunded: poor equipment, low morale, and thin reinforcement. A beleaguered outpost surviving on the edge.
