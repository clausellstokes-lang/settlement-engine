
/**
 * terrainHelpers.js
 * Terrain type resolution and geographic modifiers
 */

import {RESOURCE_DATA} from '../data/resourceData.js';

// ─────────────────────────────────────────────────────────

// getTerrainType — map trade route to terrain category
// terrainOverride allows explicit desert/mountain/hills selection
export const getTerrainType = (tradeRoute, terrainOverride = null) => {
  if (terrainOverride && terrainOverride !== 'auto') return terrainOverride;
  return ({
    port: "coastal",
    river: "riverside",
    crossroads: "plains",
    road: "plains",
    isolated: "forest",
    mountain_pass: "mountain",
    mountain_road: "mountain",
    desert_road: "desert",
  })[tradeRoute] || "plains";
};

// getCompatibleResources
export const getCompatibleResources = (route, terrain = null) =>
  Object.entries(RESOURCE_DATA).map(([key, r]) => {
    const routeBlocked = (r.forbidden || []).includes(route);
    const resTerrain = r.terrain || null; // desert, mountain, or null (universal)

    let compatible, incompatibleReason;

    if (resTerrain) {
      // Terrain-specific resource: only show when that terrain is selected
      if (!terrain) {
        // No terrain override — hide terrain-specific resources from generic routes
        compatible = false;
        incompatibleReason = 'Requires ' + resTerrain + ' terrain override';
      } else if (terrain === resTerrain) {
        // Terrain matches — always compatible regardless of route
        compatible = true;
        incompatibleReason = null;
      } else {
        // Wrong terrain — hide it
        compatible = false;
        incompatibleReason = 'Only available in ' + resTerrain + ' terrain';
      }
    } else {
      // Universal resource: use route-based compatibility
      compatible = !routeBlocked;
      incompatibleReason = routeBlocked ? (r.warning || 'Not compatible with ' + route + ' access.') : null;
    }

    return { key, ...r, compatible, incompatibleReason };
  });

// getDefaultResources
export const getDefaultResources=r=>{const s={port:["fishing_grounds","salt_flats","deep_harbour","shipbuilding_timber"],river:["river_mills","fertile_floodplain","river_fish","river_clay"],crossroads:["grain_fields","grazing_land","crossroads_position"],road:["grain_fields","grazing_land","managed_forest"],isolated:["hunting_grounds","managed_forest","foraging_areas"]};return s[r]||s.road};
