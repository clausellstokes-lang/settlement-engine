/**
 * theme.js — Shared design constants for all components.
 * Output tabs (new/) use design.js (C.ink, etc.).
 * Configuration/panel components (this file) use uppercase constants.
 */

export const GOLD  = '#a0762a';
export const INK   = '#1c1409';
export const MUTED = '#9c8068';
export const SECOND= '#6b5340';
export const BORDER= '#c8b89a';
export const BORDER2='#e0d0b0';
export const CARD  = '#fffbf5';
export const PARCH = '#f7f0e4';
export const CARD_ALT = '#faf6ef';
export const CARD_HDR = '#faf4e8';

export const sans  = "Nunito, sans-serif";
export const serif_= "Crimson Text, Georgia, serif";
